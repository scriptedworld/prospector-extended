"""Code metrics collection for code-review skill integration.

Stub implementation — interface will be defined as the code-review skill evolves.

Usage:
    cs-code-metrics --output-file .task/code_metrics_results.json
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from claude_scripts.core.results import common_options, handle_result, make_result


def collect_metrics() -> dict[str, Any]:
    """Collect code metrics.

    Returns:
        Standardized result dict (stub — always succeeds with empty metadata).
    """
    return make_result(
        success=True,
        reasons=[],
        metadata={"status": "stub", "message": "Code metrics not yet implemented"},
    )


@click.command()
@common_options
def main(output_file: Path | None, output_format: str) -> None:
    """Collect code metrics for code-review skill.

    Stub implementation — will be expanded as the code-review skill evolves.
    """
    result = collect_metrics()
    handle_result(result, output_file, output_format)
