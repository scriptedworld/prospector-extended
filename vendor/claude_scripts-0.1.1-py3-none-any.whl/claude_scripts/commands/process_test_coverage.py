"""Process pytest + coverage output into combined results.

Combines test counts from pytest-json-report with overall coverage
percentage from coverage.json.

Usage:
    cs-process-test-coverage --test-report .task/test_results.json --coverage .task/coverage.json \
        --output-file .task/test_coverage_results.json
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from claude_scripts.core.results import common_options, handle_result, make_result


def process_test_coverage(
    test_data: dict[str, Any],
    coverage_data: dict[str, Any],
    coverage_threshold: float = 80.0,
) -> dict[str, Any]:
    """Combine test and coverage results.

    Args:
        test_data: Parsed pytest-json-report data.
        coverage_data: Parsed coverage.json data.
        coverage_threshold: Minimum coverage percentage.

    Returns:
        Standardized result dict.
    """
    summary = test_data.get("summary", {})
    collected = summary.get("collected", 0)
    passed = summary.get("passed", 0)
    failed = summary.get("failed", 0)
    errors = summary.get("errors", 0)

    totals = coverage_data.get("totals", {})
    overall_coverage = totals.get("percent_covered", 0.0)

    reasons = []
    if failed > 0:
        reasons.append(f"{failed} test(s) failed")
    if errors > 0:
        reasons.append(f"{errors} test(s) errored")
    if overall_coverage < coverage_threshold:
        reasons.append(f"Coverage {overall_coverage:.1f}% below {coverage_threshold}% threshold")

    return make_result(
        success=len(reasons) == 0,
        reasons=reasons,
        metadata={
            "tests": {
                "collected": collected,
                "passed": passed,
                "failed": failed,
                "errors": errors,
            },
            "coverage": {
                "overall": round(overall_coverage, 2),
                "threshold": coverage_threshold,
            },
        },
    )


@click.command()
@click.option("--test-report", type=click.Path(exists=True, path_type=Path), required=True, help="Path to pytest JSON report")
@click.option("--coverage", "coverage_file", type=click.Path(exists=True, path_type=Path), required=True, help="Path to coverage.json")
@click.option("--coverage-threshold", type=float, default=80.0, help="Minimum coverage percentage")
@common_options
def main(
    test_report: Path,
    coverage_file: Path,
    coverage_threshold: float,
    output_file: Path | None,
    output_format: str,
) -> None:
    """Process pytest + coverage output into combined results.

    Combines test counts from TEST_REPORT with overall coverage from COVERAGE_FILE.
    """
    try:
        test_data = json.loads(test_report.read_text())
        coverage_data = json.loads(coverage_file.read_text())
    except json.JSONDecodeError as exc:
        handle_result(make_result(False, [f"Invalid JSON input: {exc}"], {}), output_file, output_format)
        return
    result = process_test_coverage(test_data, coverage_data, coverage_threshold)
    handle_result(result, output_file, output_format)
