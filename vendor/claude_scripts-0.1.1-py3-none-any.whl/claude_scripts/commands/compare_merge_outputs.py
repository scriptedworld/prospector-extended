"""Compare two merge output JSON files for differences.

Deep recursive comparison of two JSON structures, reporting differences
by JSON path. Supports ignoring specified fields.

Usage:
    cs-compare-merge-outputs test_merge.json real_merge.json --ignore-fields timestamp commit_sha \
        --output-file .task/merge_comparison_results.json
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from claude_scripts.core.results import common_options, handle_result, make_result


def _compare_dicts(path: str, val1: dict[str, Any], val2: dict[str, Any], ignore_fields: set[str]) -> list[dict[str, Any]]:
    """Compare two dicts and collect differences by key.

    Args:
        path: Current JSON path.
        val1: First dict.
        val2: Second dict.
        ignore_fields: Field names to skip.

    Returns:
        List of difference dicts.
    """
    diffs: list[dict[str, Any]] = []
    for key in sorted(set(val1.keys()) | set(val2.keys())):
        if key in ignore_fields:
            continue
        child_path = f"{path}.{key}" if path else key
        if key not in val1:
            diffs.append({"path": child_path, "type": "added", "value": val2[key]})
        elif key not in val2:
            diffs.append({"path": child_path, "type": "removed", "value": val1[key]})
        else:
            diffs.extend(_compare_values(child_path, val1[key], val2[key], ignore_fields))
    return diffs


def _compare_lists(path: str, val1: list[Any], val2: list[Any], ignore_fields: set[str]) -> list[dict[str, Any]]:
    """Compare two lists element by element.

    Args:
        path: Current JSON path.
        val1: First list.
        val2: Second list.
        ignore_fields: Field names to skip.

    Returns:
        List of difference dicts.
    """
    diffs: list[dict[str, Any]] = []
    for i in range(max(len(val1), len(val2))):
        child_path = f"{path}[{i}]"
        if i >= len(val1):
            diffs.append({"path": child_path, "type": "added", "value": val2[i]})
        elif i >= len(val2):
            diffs.append({"path": child_path, "type": "removed", "value": val1[i]})
        else:
            diffs.extend(_compare_values(child_path, val1[i], val2[i], ignore_fields))
    return diffs


def _compare_values(path: str, val1: Any, val2: Any, ignore_fields: set[str]) -> list[dict[str, Any]]:
    """Recursively compare two values and collect differences.

    Args:
        path: Current JSON path (dot-separated).
        val1: Value from first file.
        val2: Value from second file.
        ignore_fields: Field names to skip.

    Returns:
        List of difference dicts.
    """
    if isinstance(val1, dict) and isinstance(val2, dict):
        return _compare_dicts(path, val1, val2, ignore_fields)
    if isinstance(val1, list) and isinstance(val2, list):
        return _compare_lists(path, val1, val2, ignore_fields)
    if val1 != val2:
        return [{"path": path, "type": "changed", "expected": val1, "actual": val2}]
    return []


def compare_merge_outputs(
    data1: dict[str, Any],
    data2: dict[str, Any],
    ignore_fields: list[str] | None = None,
) -> dict[str, Any]:
    """Compare two merge output JSON structures.

    Args:
        data1: First (expected/test) merge output.
        data2: Second (actual/real) merge output.
        ignore_fields: Field names to ignore in comparison.

    Returns:
        Standardized result dict.
    """
    ignore_set = set(ignore_fields or [])
    diffs = _compare_values("", data1, data2, ignore_set)

    reasons = []
    if diffs:
        reasons.append(f"{len(diffs)} difference(s) found between merge outputs")

    return make_result(
        success=len(diffs) == 0,
        reasons=reasons,
        metadata={
            "differences_count": len(diffs),
            "differences": diffs,
            "ignored_fields": sorted(ignore_set),
        },
    )


@click.command()
@click.argument("file1", type=click.Path(exists=True, path_type=Path))
@click.argument("file2", type=click.Path(exists=True, path_type=Path))
@click.option("--ignore-fields", multiple=True, help="Field names to ignore in comparison")
@common_options
def main(
    file1: Path,
    file2: Path,
    ignore_fields: tuple[str, ...],
    output_file: Path | None,
    output_format: str,
) -> None:
    """Compare two merge output JSON files.

    Deep recursive comparison of FILE1 and FILE2, reporting differences
    by JSON path.
    """
    try:
        data1 = json.loads(file1.read_text())
        data2 = json.loads(file2.read_text())
    except json.JSONDecodeError as exc:
        handle_result(make_result(False, [f"Invalid JSON input: {exc}"], {}), output_file, output_format)
        return
    result = compare_merge_outputs(data1, data2, list(ignore_fields))
    handle_result(result, output_file, output_format)
