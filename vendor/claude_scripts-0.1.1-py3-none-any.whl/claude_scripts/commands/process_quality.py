"""Process prospector JSON output into quality results.

Reads prospector-extended JSON output and counts messages by tool and severity.

Usage:
    cs-process-quality .task/quality.json --output-file .task/quality_results.json
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from claude_scripts.core.results import common_options, handle_result, make_result


def process_quality(quality_data: dict[str, Any]) -> dict[str, Any]:
    """Process prospector JSON output.

    Args:
        quality_data: Parsed prospector JSON data.

    Returns:
        Standardized result dict.
    """
    summary = quality_data.get("summary", {})
    message_count = summary.get("message_count", 0)
    tools_run = summary.get("tools", summary.get("tools_run", []))

    messages = quality_data.get("messages", [])

    by_tool: dict[str, int] = {}
    for msg in messages:
        source = msg.get("source", "unknown")
        by_tool[source] = by_tool.get(source, 0) + 1

    reasons = []
    if message_count > 0:
        reasons.append(f"{message_count} quality issue(s) found")

    return make_result(
        success=message_count == 0,
        reasons=reasons,
        metadata={
            "message_count": message_count,
            "tools_run": tools_run,
            "by_tool": by_tool,
            "messages": [
                {
                    "source": m.get("source", ""),
                    "code": m.get("code", ""),
                    "path": m.get("location", {}).get("path", ""),
                    "line": m.get("location", {}).get("line", 0),
                    "message": m.get("message", ""),
                }
                for m in messages
            ],
        },
    )


@click.command()
@click.argument("quality_file", type=click.Path(exists=True, path_type=Path))
@common_options
def main(quality_file: Path, output_file: Path | None, output_format: str) -> None:
    """Process prospector JSON output into quality results.

    Reads QUALITY_FILE (prospector-extended JSON output) and extracts
    message counts, tool results, and issue details.
    """
    try:
        quality_data = json.loads(quality_file.read_text())
    except json.JSONDecodeError as exc:
        handle_result(make_result(False, [f"Invalid JSON in {quality_file}: {exc}"], {}), output_file, output_format)
        return
    result = process_quality(quality_data)
    handle_result(result, output_file, output_format)
