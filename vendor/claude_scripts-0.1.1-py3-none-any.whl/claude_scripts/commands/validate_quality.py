"""Unified quality gate validator.

Reads already-processed quality and test/coverage results files and validates
all thresholds: coverage, lint errors, security issues, etc.

Usage:
    cs-validate-quality --quality .task/quality_results.json --coverage .task/test_coverage_results.json \
        --output-file .task/quality_validation_results.json
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from claude_scripts.core.results import common_options, handle_result, make_result


def validate_quality(
    quality_results: dict[str, Any] | None = None,
    coverage_results: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Validate all quality gates from pre-processed results.

    Args:
        quality_results: Pre-processed quality results (from cs-process-quality).
        coverage_results: Pre-processed test/coverage results (from cs-process-test-coverage).

    Returns:
        Standardized result dict.
    """
    reasons: list[str] = []
    gates: dict[str, Any] = {}

    if coverage_results:
        cov_success = coverage_results.get("success", False)
        gates["test_coverage"] = {"passed": cov_success}
        if not cov_success:
            for reason in coverage_results.get("reasons", []):
                reasons.append(f"Test/Coverage: {reason}")

    if quality_results:
        qual_success = quality_results.get("success", False)
        gates["quality"] = {"passed": qual_success}
        if not qual_success:
            for reason in quality_results.get("reasons", []):
                reasons.append(f"Quality: {reason}")

    return make_result(
        success=len(reasons) == 0,
        reasons=reasons,
        metadata={"gates": gates},
    )


@click.command()
@click.option("--quality", "quality_file", type=click.Path(exists=True, path_type=Path), default=None, help="Quality results JSON")
@click.option("--coverage", "coverage_file", type=click.Path(exists=True, path_type=Path), default=None, help="Test/coverage results JSON")
@common_options
def main(
    quality_file: Path | None,
    coverage_file: Path | None,
    output_file: Path | None,
    output_format: str,
) -> None:
    """Unified quality gate validation.

    Reads pre-processed results files and validates all quality thresholds.
    """
    try:
        quality_results = json.loads(quality_file.read_text()) if quality_file else None
        coverage_results = json.loads(coverage_file.read_text()) if coverage_file else None
    except json.JSONDecodeError as exc:
        handle_result(make_result(False, [f"Invalid JSON input: {exc}"], {}), output_file, output_format)
        return
    result = validate_quality(quality_results, coverage_results)
    handle_result(result, output_file, output_format)
