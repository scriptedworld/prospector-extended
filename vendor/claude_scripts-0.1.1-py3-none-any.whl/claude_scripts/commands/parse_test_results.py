"""Parse pytest JSON report into a clean test summary.

Extracts test counts, pass/fail status, failed test names, and duration
from pytest-json-report output.

Usage:
    cs-parse-test-results .task/test_results.json --output-file .task/test_results_parsed.json
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from claude_scripts.core.results import common_options, handle_result, make_result


def parse_test_results(report_data: dict[str, Any]) -> dict[str, Any]:
    """Parse pytest JSON report into standardized result.

    Args:
        report_data: Parsed pytest-json-report data.

    Returns:
        Standardized result dict.
    """
    summary = report_data.get("summary", {})
    collected = summary.get("collected", 0)
    passed = summary.get("passed", 0)
    failed = summary.get("failed", 0)
    errors = summary.get("errors", 0)
    skipped = summary.get("skipped", 0)
    duration = report_data.get("duration", 0.0)

    failed_tests = []
    for test in report_data.get("tests", []):
        if test.get("outcome") in ("failed", "error"):
            call_info = test.get("call", {})
            longrepr = call_info.get("longrepr", "")
            short_msg = longrepr.split("\n")[-1] if longrepr else ""
            failed_tests.append(
                {
                    "nodeid": test.get("nodeid", ""),
                    "outcome": test.get("outcome", ""),
                    "message": short_msg[:200],
                }
            )

    reasons = []
    if failed > 0:
        reasons.append(f"{failed} test(s) failed")
    if errors > 0:
        reasons.append(f"{errors} test(s) errored")

    return make_result(
        success=failed == 0 and errors == 0,
        reasons=reasons,
        metadata={
            "collected": collected,
            "passed": passed,
            "failed": failed,
            "errors": errors,
            "skipped": skipped,
            "duration": round(duration, 2),
            "failed_tests": failed_tests,
        },
    )


@click.command()
@click.argument("test_report", type=click.Path(exists=True, path_type=Path))
@common_options
def main(test_report: Path, output_file: Path | None, output_format: str) -> None:
    """Parse pytest JSON report into clean test summary.

    Reads TEST_REPORT (pytest-json-report output) and extracts test counts,
    pass/fail status, failed test names, and duration.
    """
    try:
        report_data = json.loads(test_report.read_text())
    except json.JSONDecodeError as exc:
        handle_result(make_result(False, [f"Invalid JSON in {test_report}: {exc}"], {}), output_file, output_format)
        return
    result = parse_test_results(report_data)
    handle_result(result, output_file, output_format)
