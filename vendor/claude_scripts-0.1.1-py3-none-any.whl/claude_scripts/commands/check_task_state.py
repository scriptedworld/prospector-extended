"""Validate task_info.json structure and state.

Checks required fields, status matches expected value, and task branch exists.

Usage:
    cs-check-task-state .task/task_info.json --expected-status in_progress \
        --output-file .task/task_state_results.json
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from claude_scripts.core.process import run_command
from claude_scripts.core.results import common_options, handle_result, make_result

REQUIRED_FIELDS = ["task_id", "status", "task_type", "task_branch", "skill_executions"]


def check_task_state(
    task_info: dict[str, Any],
    expected_status: str | None = None,
    check_branch: bool = True,
) -> dict[str, Any]:
    """Validate task_info.json structure and state.

    Args:
        task_info: Parsed task_info.json data.
        expected_status: If provided, status must match this value.
        check_branch: Whether to verify git branch exists.

    Returns:
        Standardized result dict.
    """
    reasons: list[str] = []

    missing_fields = [f for f in REQUIRED_FIELDS if f not in task_info]
    if missing_fields:
        reasons.append(f"Missing required fields: {', '.join(missing_fields)}")

    actual_status = task_info.get("status", "")
    if expected_status and actual_status != expected_status:
        reasons.append(f"Status '{actual_status}' does not match expected '{expected_status}'")

    branch = task_info.get("task_branch", "")
    branch_exists = False
    if check_branch and branch:
        success, stdout, _stderr = run_command(["git", "branch", "--list", branch])
        branch_exists = success and branch in stdout

        if not branch_exists:
            success, stdout, _stderr = run_command(["git", "branch", "--show-current"])
            if success and stdout == branch:
                branch_exists = True

        if not branch_exists:
            reasons.append(f"Task branch '{branch}' not found in git")

    return make_result(
        success=len(reasons) == 0,
        reasons=reasons,
        metadata={
            "task_id": task_info.get("task_id", ""),
            "status": actual_status,
            "task_type": task_info.get("task_type", ""),
            "task_branch": branch,
            "branch_exists": branch_exists,
            "skill_count": len(task_info.get("skill_executions", [])),
        },
    )


@click.command()
@click.argument("task_info_path", type=click.Path(exists=True, path_type=Path))
@click.option("--expected-status", type=str, default=None, help="Expected task status")
@click.option("--no-check-branch", is_flag=True, default=False, help="Skip git branch check")
@common_options
def main(
    task_info_path: Path,
    expected_status: str | None,
    no_check_branch: bool,
    output_file: Path | None,
    output_format: str,
) -> None:
    """Validate task_info.json structure and state.

    Checks TASK_INFO_PATH for required fields, expected status,
    and git branch existence.
    """
    try:
        task_info = json.loads(task_info_path.read_text())
    except json.JSONDecodeError as exc:
        handle_result(make_result(False, [f"Invalid JSON in {task_info_path}: {exc}"], {}), output_file, output_format)
        return
    result = check_task_state(task_info, expected_status, check_branch=not no_check_branch)
    handle_result(result, output_file, output_format)
