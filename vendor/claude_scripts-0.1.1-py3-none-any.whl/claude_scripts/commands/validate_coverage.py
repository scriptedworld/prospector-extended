"""Per-file, per-branch coverage validator.

Reads coverage.json and validates that every file meets minimum thresholds
for BOTH statement coverage AND branch coverage.

Usage:
    cs-validate-coverage .task/coverage.json --threshold 80.0 --output-file .task/coverage_results.json
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from claude_scripts.core.results import common_options, handle_result, make_result


def validate_coverage(
    coverage_data: dict[str, Any],
    threshold: float = 80.0,
    exclude_patterns: list[str] | None = None,
) -> dict[str, Any]:
    """Validate per-file, per-branch coverage.

    Args:
        coverage_data: Parsed coverage.json data.
        threshold: Minimum coverage percentage.
        exclude_patterns: File patterns to exclude.

    Returns:
        Standardized result dict.
    """
    if exclude_patterns is None:
        exclude_patterns = []

    files = coverage_data.get("files", {})
    failing = []
    passing = []

    for path, info in sorted(files.items()):
        if any(pattern in path for pattern in exclude_patterns):
            continue

        summary = info["summary"]
        stmt_coverage = summary["percent_covered"]

        num_branches = summary["num_branches"]
        partial_branches = summary["num_partial_branches"]

        branch_coverage = (num_branches - partial_branches) / num_branches * 100 if num_branches > 0 else 100.0

        meets_threshold = stmt_coverage >= threshold and branch_coverage >= threshold

        file_result = {
            "file": path,
            "statement_coverage": round(stmt_coverage, 2),
            "branch_coverage": round(branch_coverage, 2),
            "num_statements": summary["num_statements"],
            "num_branches": num_branches,
            "partial_branches": partial_branches,
        }

        if meets_threshold:
            passing.append(file_result)
        else:
            failing.append(file_result)

    reasons = []
    if failing:
        reasons.append(f"{len(failing)} file(s) below {threshold}% threshold")

    return make_result(
        success=len(failing) == 0,
        reasons=reasons,
        metadata={
            "threshold": threshold,
            "total_files": len(passing) + len(failing),
            "passing_files": len(passing),
            "failing_files": len(failing),
            "passing": passing,
            "failing": failing,
        },
    )


@click.command()
@click.argument("coverage_file", type=click.Path(exists=True, path_type=Path))
@click.option("--threshold", type=float, default=80.0, help="Minimum coverage percentage (default: 80.0)")
@click.option("--exclude", multiple=True, help="File patterns to exclude")
@common_options
def main(
    coverage_file: Path,
    threshold: float,
    exclude: tuple[str, ...],
    output_file: Path | None,
    output_format: str,
) -> None:
    """Validate per-file, per-branch coverage thresholds.

    Reads COVERAGE_FILE (coverage.json) and validates that every file meets
    the minimum threshold for BOTH statement and branch coverage.
    """
    try:
        coverage_data = json.loads(coverage_file.read_text())
    except json.JSONDecodeError as exc:
        handle_result(make_result(False, [f"Invalid JSON in {coverage_file}: {exc}"], {}), output_file, output_format)
        return
    result = validate_coverage(coverage_data, threshold, list(exclude))
    handle_result(result, output_file, output_format)
