"""Verify session state in bootstrapping mode.

Checks Python, UV, git branch, git status, and development tool installation.
Used when poe tasks aren't yet configured.

Usage:
    cs-verify-session-bootstrap --output-file .task/session_bootstrap_results.json
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from claude_scripts.core.process import run_command
from claude_scripts.core.results import common_options, handle_result, make_result

DEV_TOOLS: list[dict[str, Any]] = [
    {"name": "pytest", "cmd": ["uv", "run", "pytest", "--version"], "phase": "1a.02"},
    {"name": "ruff", "cmd": ["uv", "run", "ruff", "--version"], "phase": "1a.03"},
    {"name": "mypy", "cmd": ["uv", "run", "mypy", "--version"], "phase": "1a.04"},
    {"name": "bandit", "cmd": ["uv", "run", "bandit", "--version"], "phase": "1a.05"},
    {"name": "vulture", "cmd": ["uv", "run", "vulture", "--version"], "phase": "1a.06"},
    {"name": "prospector", "cmd": ["uv", "run", "prospector", "--version"], "phase": "1b.01"},
    {"name": "complexipy", "cmd": ["uv", "run", "complexipy", "--help"], "phase": "1b.01"},
    {"name": "interrogate", "cmd": ["uv", "run", "interrogate", "--version"], "phase": "1b.01"},
    {"name": "pyright", "cmd": ["uv", "run", "pyright", "--version"], "phase": "1b.01"},
]


def parse_tool_check(success: bool, stdout: str, phase: str) -> dict[str, Any]:
    """Parse the result of a dev tool check.

    Args:
        success: Whether the command succeeded.
        stdout: Command stdout output.
        phase: Phase identifier for this tool.

    Returns:
        Status dict with installed, status, phase, and optional version.
    """
    if success:
        version_line = stdout.split("\n", maxsplit=1)[0] if stdout else ""
        return {"installed": True, "status": "ok", "version": version_line, "phase": phase}
    return {"installed": False, "status": "not_installed", "phase": phase}


def parse_version_check(success: bool, stdout: str, stderr: str, name: str) -> tuple[dict[str, Any], str | None]:
    """Parse a version check result (python, uv).

    Args:
        success: Whether the command succeeded.
        stdout: Command stdout.
        stderr: Command stderr.
        name: Name of the tool being checked.

    Returns:
        Tuple of (status dict, failure reason or None).
    """
    if success:
        return {"version": stdout, "status": "ok"}, None
    return {"error": stderr, "status": "failed"}, f"{name} not available"


def parse_git_branch(success: bool, stdout: str, stderr: str) -> tuple[dict[str, Any], str | None]:
    """Parse git branch check result.

    Args:
        success: Whether the command succeeded.
        stdout: Branch name from stdout.
        stderr: Error output.

    Returns:
        Tuple of (status dict, failure reason or None).
    """
    if success:
        is_session = stdout.startswith("session/")
        return {
            "branch": stdout,
            "is_session_branch": is_session,
            "status": "ok" if is_session else "warning",
        }, None
    return {"error": stderr, "status": "failed"}, "Git branch check failed"


def parse_git_status(success: bool, stdout: str, stderr: str) -> dict[str, Any]:
    """Parse git status check result.

    Args:
        success: Whether the command succeeded.
        stdout: Status output.
        stderr: Error output.

    Returns:
        Status dict.
    """
    if success:
        clean = len(stdout) == 0
        return {
            "clean": clean,
            "status": "ok" if clean else "warning",
            "changes": stdout.split("\n") if stdout else [],
        }
    return {"error": stderr, "status": "failed"}


def build_bootstrap_result(
    verification: dict[str, Any],
    reasons: list[str],
    dev_tools: dict[str, Any],
    installed_count: int,
    total_tools: int,
) -> dict[str, Any]:
    """Build the final bootstrap verification result.

    Args:
        verification: Dict of verification check results.
        reasons: List of failure reasons.
        dev_tools: Dict of dev tool check results.
        installed_count: Number of tools installed.
        total_tools: Total number of tools checked.

    Returns:
        Standardized result dict.
    """
    return make_result(
        success=len(reasons) == 0,
        reasons=reasons,
        metadata={
            "mode": "bootstrapping",
            "verification": verification,
            "dev_tools": dev_tools,
            "dev_tools_summary": {
                "installed": installed_count,
                "total": total_tools,
                "progress": f"{installed_count}/{total_tools}",
            },
        },
    )


def check_dev_tool(tool: dict[str, Any]) -> dict[str, Any]:
    """Check if a development tool is installed and working.

    Args:
        tool: Tool definition with name, cmd, phase keys.

    Returns:
        Status dict with installed, status, and optional version.
    """
    success, stdout, _stderr = run_command(tool["cmd"])
    return parse_tool_check(success, stdout, tool["phase"])


def assemble_checks(
    checks: list[tuple[dict[str, Any], str | None]],
    git_status: dict[str, Any],
    dev_tool_results: list[tuple[str, dict[str, Any]]],
) -> dict[str, Any]:
    """Assemble parsed check results into a final bootstrap result.

    Args:
        checks: List of (status_dict, optional_reason) tuples for python, uv, git_branch.
        git_status: Parsed git status result.
        dev_tool_results: List of (tool_name, tool_result) tuples.

    Returns:
        Standardized result dict.
    """
    reasons: list[str] = []
    verification: dict[str, Any] = {}
    check_names = ["python", "uv", "git_branch"]

    for name, (status, reason) in zip(check_names, checks, strict=True):
        verification[name] = status
        if reason:
            reasons.append(reason)

    verification["git_status"] = git_status

    dev_tools: dict[str, Any] = {}
    installed_count = 0
    for tool_name, tool_result in dev_tool_results:
        dev_tools[tool_name] = tool_result
        if tool_result["installed"]:
            installed_count += 1

    return build_bootstrap_result(verification, reasons, dev_tools, installed_count, len(dev_tool_results))


def verify_bootstrap() -> dict[str, Any]:
    """Run bootstrap verification checks.

    Returns:
        Standardized result dict.
    """
    checks: list[tuple[dict[str, Any], str | None]] = []

    success, stdout, stderr = run_command(["python", "--version"])
    checks.append(parse_version_check(success, stdout, stderr, "Python"))

    success, stdout, stderr = run_command(["uv", "--version"])
    checks.append(parse_version_check(success, stdout, stderr, "UV"))

    success, stdout, stderr = run_command(["git", "branch", "--show-current"])
    checks.append(parse_git_branch(success, stdout, stderr))

    success, stdout, stderr = run_command(["git", "status", "--short"])
    git_status = parse_git_status(success, stdout, stderr)

    dev_tool_results: list[tuple[str, dict[str, Any]]] = []
    for tool in DEV_TOOLS:
        tool_result = check_dev_tool(tool)
        dev_tool_results.append((tool["name"], tool_result))

    return assemble_checks(checks, git_status, dev_tool_results)


@click.command()
@common_options
def main(output_file: Path | None, output_format: str) -> None:
    """Verify session state for bootstrapping mode.

    Checks Python, UV, git branch, git status, and development tool
    installation progress.
    """
    result = verify_bootstrap()
    handle_result(result, output_file, output_format)
