"""Config-driven workflow validation for skill execution sequences.

Validates that skill executions in task_info.json follow the correct workflow
state machine (TDD or CONFIG). Uses a YAML-configured directed graph engine.

Usage::

    cs-validate-process validate .task/task_info.json -t tdd
    cs-validate-process next .task/task_info.json -t tdd
    cs-validate-process can-run tdd-red .task/task_info.json -t tdd
    cs-validate-process workflows
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click
import yaml

from claude_scripts.core.results import common_options, handle_result, make_result
from claude_scripts.core.workflow import WorkflowGraph, WorkflowRegistry

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_TASK_INFO = Path(".task/task_info.json")
DEFAULT_CONFIG = Path(__file__).resolve().parent.parent / "config" / "workflow.yaml"

# ---------------------------------------------------------------------------
# Internal error type
# ---------------------------------------------------------------------------


class _WorkflowError(Exception):
    """Internal error for workflow validation failures."""

    def __init__(self, reason: str, **metadata: Any) -> None:
        super().__init__(reason)
        self.reason = reason
        self.metadata: dict[str, Any] = metadata


# ---------------------------------------------------------------------------
# Shared loading helpers
# ---------------------------------------------------------------------------


def _load_registry(config: Path) -> WorkflowRegistry:
    """Load WorkflowRegistry, raising _WorkflowError on failure.

    Args:
        config: Path to workflow YAML config.

    Returns:
        Loaded WorkflowRegistry.

    Raises:
        _WorkflowError: If config is missing or invalid.
    """
    if not config.exists():
        raise _WorkflowError(f"Workflow config not found: {config}")
    try:
        return WorkflowRegistry(config)
    except (yaml.YAMLError, ValueError, KeyError) as exc:
        raise _WorkflowError(f"Failed to load workflow config: {exc}", config=str(config)) from exc


def _get_graph(registry: WorkflowRegistry, workflow_type: str) -> WorkflowGraph:
    """Get workflow graph by type, raising _WorkflowError on failure.

    Args:
        registry: Loaded workflow registry.
        workflow_type: Workflow type key.

    Returns:
        WorkflowGraph for the given type.

    Raises:
        _WorkflowError: If workflow type is unknown.
    """
    try:
        return registry.get(workflow_type)
    except KeyError as exc:
        raise _WorkflowError(str(exc)) from exc


def _load_executions(path: Path) -> list[dict[str, str]]:
    """Load skill_executions from task_info.json.

    Args:
        path: Path to task_info.json.

    Returns:
        List of skill execution records.

    Raises:
        _WorkflowError: If file is missing, malformed, or lacks required keys.
    """
    if not path.exists():
        raise _WorkflowError(f"task_info file not found: {path}")
    try:
        task_info = json.loads(path.read_text())
    except json.JSONDecodeError as exc:
        raise _WorkflowError(f"task_info file is not valid JSON: {exc}", path=str(path)) from exc
    if "skill_executions" not in task_info:
        raise _WorkflowError("task_info.json is missing required 'skill_executions' key", path=str(path))
    executions = task_info["skill_executions"]
    if not isinstance(executions, list):
        raise _WorkflowError("'skill_executions' must be a list", path=str(path))
    return executions


# ---------------------------------------------------------------------------
# Result conversion helpers
# ---------------------------------------------------------------------------


def _validate_to_result(raw: dict[str, Any], workflow_type: str) -> dict[str, Any]:
    """Convert WorkflowGraph.validate() output to results schema.

    Args:
        raw: Raw output from WorkflowGraph.validate().
        workflow_type: Workflow type key for metadata.

    Returns:
        Standardized result dict.
    """
    if raw["result"] == "FAIL":
        return make_result(False, [raw["reason"]], {"current_state": raw.get("current_state"), "complete": False, "workflow_type": workflow_type})
    return make_result(True, [], {"current_state": raw["current_state"], "complete": raw["complete"], "workflow_type": workflow_type})


def _next_to_result(raw: dict[str, Any], workflow_type: str) -> dict[str, Any]:
    """Convert WorkflowGraph.next_states() output to results schema.

    Args:
        raw: Raw output from WorkflowGraph.next_states().
        workflow_type: Workflow type key for metadata.

    Returns:
        Standardized result dict.
    """
    if raw["result"] == "FAIL":
        return make_result(False, [raw["reason"]], {"current_state": raw.get("current_state"), "workflow_type": workflow_type})
    meta = {"current_state": raw["current_state"], "next_skill": raw["next_skill"], "complete": raw["complete"], "workflow_type": workflow_type}
    return make_result(True, [], meta)


def _can_run_to_result(raw: dict[str, Any], workflow_type: str) -> dict[str, Any]:
    """Convert WorkflowGraph.can_run() output to results schema.

    Args:
        raw: Raw output from WorkflowGraph.can_run().
        workflow_type: Workflow type key for metadata.

    Returns:
        Standardized result dict.
    """
    if raw["result"] == "FAIL":
        return make_result(
            False,
            [raw.get("reason", "Workflow is in a failed state.")],
            {"skill": raw.get("skill"), "current_state": raw.get("current_state"), "allowed": False, "workflow_type": workflow_type},
        )
    allowed = raw["allowed"]
    reasons = [raw["reason"]] if not allowed and "reason" in raw else []
    return make_result(
        allowed, reasons, {"skill": raw["skill"], "current_state": raw["current_state"], "allowed": allowed, "workflow_type": workflow_type}
    )


# ---------------------------------------------------------------------------
# Shared Click options
# ---------------------------------------------------------------------------

_config_option = click.option(
    "--config",
    "config_path",
    type=click.Path(path_type=Path),
    default=None,
    help="Path to workflow YAML config.",
)

_workflow_option = click.option(
    "--workflow-type",
    "-t",
    required=True,
    help="Workflow type key (e.g. tdd, config).",
)

_task_info_arg = click.argument(
    "task_info_path",
    type=click.Path(path_type=Path),
    default=None,
    required=False,
)


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------


@click.group()
def cli() -> None:
    """Validate skill execution sequences against workflow graphs."""


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------


@cli.command()
@_task_info_arg
@_workflow_option
@_config_option
@common_options
def validate(
    task_info_path: Path | None,
    workflow_type: str,
    config_path: Path | None,
    output_file: Path | None,
    output_format: str,
) -> None:
    """Validate the full skill_executions history.

    Checks that every recorded execution follows a valid edge in the
    workflow graph, and reports whether the workflow is complete.
    """
    try:
        config = config_path or DEFAULT_CONFIG
        graph = _get_graph(_load_registry(config), workflow_type)
        executions = _load_executions(task_info_path or DEFAULT_TASK_INFO)
        result = _validate_to_result(graph.validate(executions), workflow_type)
    except _WorkflowError as exc:
        result = make_result(False, [exc.reason], exc.metadata)
    handle_result(result, output_file, output_format)


# ---------------------------------------------------------------------------
# next
# ---------------------------------------------------------------------------


@cli.command(name="next")
@_task_info_arg
@_workflow_option
@_config_option
@common_options
def next_cmd(
    task_info_path: Path | None,
    workflow_type: str,
    config_path: Path | None,
    output_file: Path | None,
    output_format: str,
) -> None:
    """Show which skill is valid to run next given current execution history."""
    try:
        config = config_path or DEFAULT_CONFIG
        graph = _get_graph(_load_registry(config), workflow_type)
        executions = _load_executions(task_info_path or DEFAULT_TASK_INFO)
        result = _next_to_result(graph.next_states(executions), workflow_type)
    except _WorkflowError as exc:
        result = make_result(False, [exc.reason], exc.metadata)
    handle_result(result, output_file, output_format)


# ---------------------------------------------------------------------------
# can-run
# ---------------------------------------------------------------------------


@cli.command(name="can-run")
@click.argument("skill_name")
@_task_info_arg
@_workflow_option
@_config_option
@common_options
def can_run(
    skill_name: str,
    task_info_path: Path | None,
    workflow_type: str,
    config_path: Path | None,
    output_file: Path | None,
    output_format: str,
) -> None:
    """Check whether SKILL_NAME is a valid next step.

    SKILL_NAME is the candidate skill to check.
    TASK_INFO_PATH defaults to .task/task_info.json.
    """
    try:
        config = config_path or DEFAULT_CONFIG
        graph = _get_graph(_load_registry(config), workflow_type)
        executions = _load_executions(task_info_path or DEFAULT_TASK_INFO)
        result = _can_run_to_result(graph.can_run(skill_name, executions), workflow_type)
    except _WorkflowError as exc:
        result = make_result(False, [exc.reason], exc.metadata)
    handle_result(result, output_file, output_format)


# ---------------------------------------------------------------------------
# workflows
# ---------------------------------------------------------------------------


@cli.command(name="workflows")
@_config_option
@common_options
def list_workflows(
    config_path: Path | None,
    output_file: Path | None,
    output_format: str,
) -> None:
    """List all available workflow types defined in the config."""
    try:
        config = config_path or DEFAULT_CONFIG
        registry = _load_registry(config)
        result = make_result(True, [], {"workflows": registry.list_workflows()})
    except _WorkflowError as exc:
        result = make_result(False, [exc.reason], exc.metadata)
    handle_result(result, output_file, output_format)
