"""Command entry points for claude-scripts."""
