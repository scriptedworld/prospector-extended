"""Verify session state using poe tasks (standard mode).

Runs format check, tests, and quality via poe tasks and captures
structured JSON output for verification.

Usage:
    cs-verify-session-std --project-root /path/to/project --output-file .task/session_std_results.json
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from claude_scripts.core.process import run_command
from claude_scripts.core.results import common_options, handle_result, make_result


def read_json_file(path: Path) -> dict[str, Any] | None:
    """Read and parse a JSON file.

    Args:
        path: Path to JSON file.

    Returns:
        Parsed dict or None if not found/invalid.
    """
    try:
        result: dict[str, Any] = json.loads(path.read_text())
        return result
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def parse_test_report(json_report: dict[str, Any] | None) -> dict[str, Any]:
    """Parse a pytest JSON report into a test results summary.

    Args:
        json_report: Parsed pytest JSON report, or None if unavailable.

    Returns:
        Test results dict with collected, passed, failed, errors, status keys.
    """
    result: dict[str, Any] = {
        "collected": 0,
        "passed": 0,
        "failed": 0,
        "errors": 0,
        "status": "unknown",
    }

    if json_report:
        summary = json_report.get("summary", {})
        result["collected"] = summary.get("collected", 0)
        result["passed"] = summary.get("passed", 0)
        result["failed"] = summary.get("failed", 0)
        result["errors"] = summary.get("errors", 0)

        if result["failed"] > 0 or result["errors"] > 0:
            result["status"] = "failed"
        elif result["passed"] == result["collected"] and result["collected"] > 0:
            result["status"] = "passed"

    return result


def parse_quality_output(stdout: str) -> dict[str, Any]:
    """Parse prospector JSON output into a quality results summary.

    Args:
        stdout: Raw stdout from the quality command.

    Returns:
        Quality results dict with message_count, tools_run, status keys.
    """
    result: dict[str, Any] = {
        "message_count": 0,
        "tools_run": [],
        "status": "unknown",
    }

    try:
        data = json.loads(stdout)
        summary = data.get("summary", {})
        result["message_count"] = summary.get("message_count", 0)
        result["tools_run"] = summary.get("tools", [])
        result["status"] = "passed"
    except json.JSONDecodeError:
        result["status"] = "failed"
        result["error"] = "Invalid JSON output"

    return result


def parse_format_output(stdout: str) -> dict[str, Any]:
    """Parse format check output into a results summary.

    Args:
        stdout: Raw stdout from the format command.

    Returns:
        Format results dict with status and optional output keys.
    """
    if "file reformatted" in stdout.lower():
        return {"status": "reformatted", "output": stdout[:200]}
    return {"status": "passed"}


def get_test_results(project_root: Path) -> dict[str, Any]:
    """Run poe test and get results from JSON report.

    Args:
        project_root: Path to project root.

    Returns:
        Test results dict.
    """
    run_command(["uv", "run", "poe", "test"], timeout=180, cwd=project_root)
    json_report = read_json_file(project_root / ".task" / "test_results.json")
    return parse_test_report(json_report)


def get_quality_results(project_root: Path) -> dict[str, Any]:
    """Run poe quality and parse JSON output.

    Args:
        project_root: Path to project root.

    Returns:
        Quality results dict.
    """
    _success, stdout, _stderr = run_command(["uv", "run", "poe", "quality"], timeout=180, cwd=project_root)
    return parse_quality_output(stdout)


def run_format_check(project_root: Path) -> dict[str, Any]:
    """Run poe format to check code formatting.

    Args:
        project_root: Path to project root.

    Returns:
        Format check results dict.
    """
    _success, stdout, _stderr = run_command(["uv", "run", "poe", "format"], timeout=60, cwd=project_root)
    return parse_format_output(stdout)


def build_verification(
    git_branch: dict[str, Any],
    format_results: dict[str, Any],
    test_results: dict[str, Any],
    quality_results: dict[str, Any],
) -> dict[str, Any]:
    """Build the verification result from pre-fetched component results.

    Args:
        git_branch: Git branch check results.
        format_results: Format check results.
        test_results: Test results.
        quality_results: Quality check results.

    Returns:
        Standardized result dict.
    """
    reasons: list[str] = []
    verification: dict[str, Any] = {
        "git_branch": git_branch,
        "format": format_results,
        "tests": test_results,
        "quality": quality_results,
    }

    if test_results["status"] != "passed":
        reasons.append(f"Tests {test_results['status']}: {test_results['failed']} failed, {test_results['errors']} errors")

    return make_result(
        success=len(reasons) == 0,
        reasons=reasons,
        metadata={
            "mode": "standard",
            "verification": verification,
        },
    )


def parse_git_branch_check(success: bool, stdout: str, stderr: str) -> dict[str, Any]:
    """Parse git branch check result.

    Args:
        success: Whether the command succeeded.
        stdout: Branch name from stdout.
        stderr: Error output.

    Returns:
        Git branch status dict.
    """
    if success:
        return {"branch": stdout, "status": "ok"}
    return {"error": stderr, "status": "failed"}


def verify_session(project_root: Path) -> dict[str, Any]:
    """Run standard session verification checks.

    Args:
        project_root: Path to project root.

    Returns:
        Standardized result dict.
    """
    success, stdout, stderr = run_command(["git", "branch", "--show-current"], cwd=project_root)
    git_branch = parse_git_branch_check(success, stdout, stderr)

    format_results = run_format_check(project_root)
    test_results = get_test_results(project_root)
    quality_results = get_quality_results(project_root)

    return build_verification(git_branch, format_results, test_results, quality_results)


@click.command()
@click.option("--project-root", type=click.Path(exists=True, path_type=Path), default=".", help="Project root directory")
@common_options
def main(project_root: Path, output_file: Path | None, output_format: str) -> None:
    """Verify session state using poe tasks.

    Runs format check, tests, and quality checks via poe tasks.
    """
    result = verify_session(project_root)
    handle_result(result, output_file, output_format)
