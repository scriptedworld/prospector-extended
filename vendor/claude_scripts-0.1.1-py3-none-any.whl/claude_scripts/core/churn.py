"""Git churn analysis — file change frequency from git history.

Analyzes git log to determine which files change most frequently.
Combined with complexity metrics, identifies bug hotspots.
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any

from claude_scripts.core.process import run_command
from claude_scripts.core.results import make_result


def _count_commits(path: str, since: str | None, timeout: int) -> tuple[bool, int, str]:
    """Count total commits in the repo.

    Args:
        path: Path to the git repository.
        since: Optional date filter.
        timeout: Maximum seconds to wait.

    Returns:
        Tuple of (success, commit_count, error_message).
    """
    cmd = ["git", "rev-list", "--count", "HEAD"]
    if since:
        cmd.extend(["--since", since])
    success, stdout, stderr = run_command(cmd, timeout=timeout, cwd=Path(path))
    if not success:
        return False, 0, stderr
    try:
        return True, int(stdout.strip()), ""
    except ValueError:
        return False, 0, f"Failed to parse commit count: {stdout}"


def _get_changed_files(path: str, since: str | None, path_filter: str | None, timeout: int) -> tuple[bool, list[str], str]:
    """Get list of changed files from git log.

    Args:
        path: Path to the git repository.
        since: Optional date filter.
        path_filter: Optional path prefix filter.
        timeout: Maximum seconds to wait.

    Returns:
        Tuple of (success, file_list, error_message).
    """
    cmd = ["git", "log", "--format=format:", "--name-only"]
    if since:
        cmd.extend(["--since", since])
    if path_filter:
        cmd.extend(["--", path_filter])
    success, stdout, stderr = run_command(cmd, timeout=timeout, cwd=Path(path))
    if not success:
        return False, [], stderr
    # Filter empty lines (commit separators)
    files = [line for line in stdout.split("\n") if line.strip()]
    return True, files, ""


def analyze_churn(
    path: str,
    path_filter: str | None = None,
    since: str | None = None,
    timeout: int = 30,
) -> dict[str, Any]:
    """Analyze git history for file change frequency.

    Args:
        path: Path to the git repository.
        path_filter: Optional path prefix to filter files (e.g. "src/").
        since: Optional date string to limit history (e.g. "2024-01-01").
        timeout: Maximum seconds to wait for git commands.

    Returns:
        Result envelope with per-file change counts in metadata.
    """
    # Get commit count (may fail on empty repos — treat as 0)
    ok, total_commits, err = _count_commits(path, since, timeout)
    if not ok:
        # Check if this is an empty repo (no commits) vs a real error
        check_ok, _, check_err = run_command(["git", "rev-parse", "--git-dir"], timeout=timeout, cwd=Path(path))
        if not check_ok:
            return make_result(False, [check_err or "Not a git repository"], {"path": path})
        # Empty repo — no commits yet
        return make_result(True, [], {"path": path, "files": [], "total_commits": 0, "total_files": 0})

    # Get changed files
    ok, file_list, err = _get_changed_files(path, since, path_filter, timeout)
    if not ok:
        return make_result(False, [err or "Failed to get changed files"], {"path": path})

    # Count occurrences per file
    counts = Counter(file_list)

    # Build ranked list (highest churn first)
    files = [{"path": filepath, "changes": count} for filepath, count in counts.most_common()]

    return make_result(
        True,
        [],
        {
            "path": path,
            "files": files,
            "total_commits": total_commits,
            "total_files": len(files),
        },
    )
