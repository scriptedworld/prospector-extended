"""Config-driven directed graph engine for workflow validation.

Each state in the graph has an expected ``skill`` and a ``next`` state.
Validation replays a skill_executions log against this structure —
the current state dictates which skill is expected, and a successful
execution advances to the next state.

skill_executions entries::

    {"skill": "<skill-name>", "result": "SUCCESS|FAIL|DELEGATED"}

Only SUCCESS and DELEGATED advance state. FAIL halts immediately.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

ADVANCING_RESULTS = {"SUCCESS", "DELEGATED"}
StateId = str


class WorkflowGraph:
    """Directed state machine loaded from a YAML workflow definition.

    Each state has:
        skill — the skill expected to run in this state (absent on final states)
        next  — the state to advance to after a successful execution
        final — bool, marks terminal states (no skill/next required)
    """

    def __init__(self, name: str, definition: dict[str, Any]) -> None:
        """Initialize a workflow graph from a definition dict.

        Args:
            name: Workflow name (e.g. "tdd", "config").
            definition: Dict with 'initial' and 'states' keys.

        Raises:
            ValueError: If the definition is internally inconsistent.
        """
        self.name = name
        self.initial: StateId = definition["initial"]
        self.states: dict[StateId, dict[str, Any]] = definition["states"]
        self._validate_definition()

    def _validate_definition(self) -> None:
        """Check internal consistency of the workflow definition.

        Raises:
            ValueError: If initial state is missing, non-final states lack
                required keys, or next states reference unknown states.
        """
        if self.initial not in self.states:
            raise ValueError(f"Workflow '{self.name}': initial state '{self.initial}' not found in states.")
        for state_id, spec in self.states.items():
            if spec.get("final"):
                continue
            if "skill" not in spec:
                raise ValueError(f"Workflow '{self.name}': non-final state '{state_id}' is missing required 'skill' key.")
            if "next" not in spec:
                raise ValueError(f"Workflow '{self.name}': non-final state '{state_id}' is missing required 'next' key.")
            next_state = spec["next"]
            if next_state not in self.states:
                raise ValueError(f"Workflow '{self.name}': state '{state_id}' references unknown next state '{next_state}'.")

    def is_final(self, state_id: StateId) -> bool:
        """Check whether a state is a terminal (final) state.

        Args:
            state_id: State identifier to check.

        Returns:
            True if the state is marked as final.
        """
        return bool(self.states.get(state_id, {}).get("final", False))

    def expected_skill(self, state_id: StateId) -> str | None:
        """Return the skill expected in this state, or None if final.

        Args:
            state_id: State identifier.

        Returns:
            Skill name, or None for final states.
        """
        return self.states.get(state_id, {}).get("skill")

    def next_state(self, state_id: StateId) -> StateId | None:
        """Return the state that follows this one, or None if final.

        Args:
            state_id: State identifier.

        Returns:
            Next state identifier, or None for final states.
        """
        return self.states.get(state_id, {}).get("next")

    def _replay(self, executions: list[dict[str, str]]) -> dict[str, Any]:
        """Replay executions against the graph.

        Args:
            executions: List of skill execution records.

        Returns:
            Internal state dict with keys:
                ok      — bool
                current — current state_id (or None if not yet started)
                reason  — failure reason (only when ok=False)
                index   — index of the failing execution (only when ok=False)
        """
        if not executions:
            return {"ok": False, "current": None, "reason": "No skill executions recorded."}

        current = self.initial

        for i, entry in enumerate(executions):
            skill = entry.get("skill", "")
            result = entry.get("result", "")

            if self.is_final(current):
                return {
                    "ok": False,
                    "current": current,
                    "reason": f"Workflow already complete at state '{current}', but found additional execution for skill '{skill}'.",
                    "index": i,
                }

            expected = self.expected_skill(current)
            if skill != expected:
                return {
                    "ok": False,
                    "current": current,
                    "reason": f"State '{current}' expected skill '{expected}', but got '{skill}'.",
                    "index": i,
                }

            if result == "FAIL":
                return {
                    "ok": False,
                    "current": current,
                    "reason": f"Skill '{skill}' reported result FAIL.",
                    "index": i,
                }

            if result not in ADVANCING_RESULTS:
                return {
                    "ok": False,
                    "current": current,
                    "reason": f"Skill '{skill}' has unrecognised result '{result}'. Expected one of: {sorted(ADVANCING_RESULTS | {'FAIL'})}.",
                    "index": i,
                }

            current = self.next_state(current)  # type: ignore[assignment]

        return {"ok": True, "current": current}

    def validate(self, executions: list[dict[str, str]]) -> dict[str, Any]:
        """Validate a full execution history.

        Args:
            executions: List of skill execution records.

        Returns:
            Dict with keys:
                result        — "PASS" or "FAIL"
                current_state — state after replaying all executions
                complete      — True if current_state is final
                reason        — (FAIL only) explanation
        """
        r = self._replay(executions)
        if not r["ok"]:
            return {"result": "FAIL", "reason": r["reason"], "current_state": r["current"], "complete": False}
        complete = self.is_final(r["current"])
        return {"result": "PASS", "current_state": r["current"], "complete": complete}

    def next_states(self, executions: list[dict[str, str]]) -> dict[str, Any]:
        """Return the valid next skill given current execution history.

        Args:
            executions: List of skill execution records.

        Returns:
            Dict with keys:
                result      — "PASS" or "FAIL"
                current_state
                next_skill  — the expected next skill, or None if complete
                complete    — bool
                reason      — (FAIL only)
        """
        r = self._replay(executions)
        if not r["ok"]:
            return {"result": "FAIL", "reason": r["reason"], "current_state": r["current"], "next_skill": None, "complete": False}
        current = r["current"]
        complete = self.is_final(current)
        return {"result": "PASS", "current_state": current, "next_skill": None if complete else self.expected_skill(current), "complete": complete}

    def can_run(self, skill: str, executions: list[dict[str, str]]) -> dict[str, Any]:
        """Check whether a given skill is the valid next step.

        Args:
            skill: Candidate skill name.
            executions: List of skill execution records.

        Returns:
            Dict with keys:
                result        — "PASS" or "FAIL"
                skill
                current_state
                allowed       — bool
                reason        — (when allowed=False or result=FAIL)
        """
        nxt = self.next_states(executions)
        if nxt["result"] == "FAIL":
            return {
                "result": "FAIL",
                "skill": skill,
                "current_state": nxt.get("current_state"),
                "allowed": False,
                "reason": nxt.get("reason", "Workflow is in a failed state."),
            }

        allowed = skill == nxt["next_skill"]
        out: dict[str, Any] = {"result": "PASS", "skill": skill, "current_state": nxt["current_state"], "allowed": allowed}
        if not allowed:
            if nxt["complete"]:
                out["reason"] = "Workflow is already complete — no further skills expected."
            else:
                out["reason"] = f"'{skill}' is not the expected next skill from state '{nxt['current_state']}'. Expected: '{nxt['next_skill']}'."
        return out


class WorkflowRegistry:
    """Loads and caches all workflow graphs from a YAML config file."""

    def __init__(self, config_path: Path) -> None:
        """Initialize registry from a YAML config file.

        Args:
            config_path: Path to the workflow YAML config.

        Raises:
            FileNotFoundError: If config_path does not exist.
            yaml.YAMLError: If the YAML is malformed.
            ValueError: If workflow definitions are invalid.
        """
        self.config_path = config_path
        self._graphs: dict[str, WorkflowGraph] = {}
        self._load()

    def _load(self) -> None:
        """Load workflow definitions from the config file."""
        with self.config_path.open() as fh:
            raw = yaml.safe_load(fh)
        for name, definition in raw.get("workflows", {}).items():
            self._graphs[name] = WorkflowGraph(name, definition)

    def get(self, name: str) -> WorkflowGraph:
        """Get a workflow graph by name.

        Args:
            name: Workflow type key (e.g. "tdd", "config").

        Returns:
            The WorkflowGraph for the given name.

        Raises:
            KeyError: If the workflow type is not found.
        """
        if name not in self._graphs:
            raise KeyError(f"Unknown workflow type '{name}'. Available: {sorted(self._graphs.keys())}.")
        return self._graphs[name]

    def list_workflows(self) -> list[str]:
        """List all available workflow type names.

        Returns:
            Sorted list of workflow type keys.
        """
        return sorted(self._graphs.keys())
