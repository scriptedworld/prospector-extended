"""Core utilities for claude-scripts."""
