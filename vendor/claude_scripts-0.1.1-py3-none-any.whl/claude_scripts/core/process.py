"""Shared subprocess runner for claude-scripts commands.

Provides a safe wrapper around subprocess.run with timeout handling
and structured return values.
"""

from __future__ import annotations

import subprocess
from pathlib import Path


def run_command(
    cmd: list[str],
    timeout: int = 30,
    cwd: Path | None = None,
) -> tuple[bool, str, str]:
    """Run a command and return structured results.

    Args:
        cmd: Command and arguments to execute.
        timeout: Maximum seconds to wait (default: 30).
        cwd: Working directory for the command.

    Returns:
        Tuple of (success, stdout, stderr).
    """
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
            cwd=cwd,
        )
        return result.returncode == 0, result.stdout.strip(), result.stderr.strip()
    except subprocess.TimeoutExpired:
        return False, "", "Command timed out"
    except FileNotFoundError:
        return False, "", f"Command not found: {cmd[0]}"
    except OSError as e:
        return False, "", str(e)
