"""Radon metrics subprocess runner.

Thin wrapper that shells out to radon subcommands (cc, raw, mi) and returns
structured results in the standard result envelope format.
"""

from __future__ import annotations

import json
from typing import Any

from claude_scripts.core.process import run_command
from claude_scripts.core.results import make_result


def _run_radon(subcommand: str, path: str, timeout: int) -> dict[str, Any]:
    """Run a radon subcommand and return a result envelope.

    Args:
        subcommand: Radon subcommand (cc, raw, mi).
        path: File or directory path to analyze.
        timeout: Maximum seconds to wait.

    Returns:
        Result envelope with radon data in metadata.
    """
    success, stdout, stderr = run_command(["radon", subcommand, "--json", path], timeout=timeout)

    if not success:
        return make_result(False, [stderr or f"radon {subcommand} failed"], {"command": subcommand, "path": path})

    try:
        results = json.loads(stdout) if stdout else {}
    except json.JSONDecodeError:
        return make_result(False, [f"Failed to parse JSON output from radon {subcommand}"], {"command": subcommand, "path": path})

    return make_result(True, [], {"command": subcommand, "path": path, "results": results})


def run_radon_cc(path: str, timeout: int = 30) -> dict[str, Any]:
    """Run radon cyclomatic complexity analysis.

    Args:
        path: File or directory path to analyze.
        timeout: Maximum seconds to wait.

    Returns:
        Result envelope with per-function CC data in metadata.
    """
    return _run_radon("cc", path, timeout)


def run_radon_raw(path: str, timeout: int = 30) -> dict[str, Any]:
    """Run radon raw LOC metrics analysis.

    Args:
        path: File or directory path to analyze.
        timeout: Maximum seconds to wait.

    Returns:
        Result envelope with LOC/SLOC/comments data in metadata.
    """
    return _run_radon("raw", path, timeout)


def run_radon_mi(path: str, timeout: int = 30) -> dict[str, Any]:
    """Run radon maintainability index analysis.

    Args:
        path: File or directory path to analyze.
        timeout: Maximum seconds to wait.

    Returns:
        Result envelope with MI score and rank in metadata.
    """
    return _run_radon("mi", path, timeout)
