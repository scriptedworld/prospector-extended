"""Standardized results schema for all claude-scripts commands.

Every command outputs a result dict with three fields:
- success (bool): Whether the command passed
- reasons (list[str]): Human-readable failure reasons (empty on success)
- metadata (dict): Command-specific data (counts, details, etc.)
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import click


def make_result(success: bool, reasons: list[str], metadata: dict[str, Any]) -> dict[str, Any]:
    """Create a standardized results dict.

    Args:
        success: Whether the command passed.
        reasons: Human-readable failure reasons (empty on success).
        metadata: Command-specific data.

    Returns:
        Standardized result dict with success, reasons, metadata keys.
    """
    result: dict[str, Any] = {"success": success, "metadata": metadata}
    if not success:
        result["reasons"] = reasons
    return result


def write_results(result: dict[str, Any], output_path: Path) -> None:
    """Write results JSON to a file.

    Args:
        result: Standardized result dict.
        output_path: Path to write the JSON file.
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, indent=2) + "\n")


def output_results(result: dict[str, Any], output_format: str = "json") -> None:
    """Print results to stdout (json) or stderr (human).

    Args:
        result: Standardized result dict.
        output_format: Either "json" or "human".
    """
    if output_format == "json":
        print(json.dumps(result, indent=2), file=sys.stdout)  # noqa: T201
    else:
        _print_human(result)


def _print_human(result: dict[str, Any]) -> None:
    """Print human-readable results to stderr.

    Args:
        result: Standardized result dict.
    """
    if result["success"]:
        click.echo("PASS", file=sys.stderr)
    else:
        click.echo("FAIL", file=sys.stderr)
        for reason in result.get("reasons", []):
            click.echo(f"  - {reason}", file=sys.stderr)


def common_options(func: Any) -> Any:
    """Decorator adding common Click options to commands.

    Adds:
        --output-file: Path to write results JSON
        --output: Format (json or human), default json
    """
    func = click.option(
        "--output-file",
        type=click.Path(path_type=Path),
        default=None,
        help="Path to write results JSON file",
    )(func)
    return click.option(
        "--output",
        "output_format",
        type=click.Choice(["json", "human"]),
        default="json",
        help="Output format (default: json)",
    )(func)


def handle_result(result: dict[str, Any], output_file: Path | None, output_format: str) -> None:
    """Handle result output and exit code.

    Writes results to file if specified, prints to stdout/stderr,
    and exits with appropriate code.

    Args:
        result: Standardized result dict.
        output_file: Optional path to write results JSON.
        output_format: Either "json" or "human".
    """
    if output_file:
        write_results(result, output_file)
    output_results(result, output_format)
    sys.exit(0 if result["success"] else 1)
