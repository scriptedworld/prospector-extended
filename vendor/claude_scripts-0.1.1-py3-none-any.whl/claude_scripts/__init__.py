"""claude-scripts.

Claude workflow command-line tools. Each command is an independent entry point
(cs-* prefix) that reads structured JSON input, processes/validates it, and
outputs a standardized results file.
"""

__version__ = "0.1.1"
