"""Configuration files for claude-scripts workflows."""
