"""Data.

CLI tool for JSON, YAML, and TOML manipulation
"""

__version__ = "0.5.4"
