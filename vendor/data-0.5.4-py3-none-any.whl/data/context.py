"""Context dataclass for shared state.

This module provides the Context dataclass that holds document state
and configuration during command execution.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from data.source import Source


@dataclass
class Context:
    """Shared state for command execution.

    Attributes:
        data: The current document data being manipulated.
        at_prefix: JSONPath prefix for scoped operations (defaults to $ for root).
        source: The source from which data was loaded (for writeback info).
    """

    data: Any = None
    at_prefix: str = "$"
    source: Source | None = None
