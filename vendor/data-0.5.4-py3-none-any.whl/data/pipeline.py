"""Pipeline orchestration for command execution.

This module provides the core pipeline that coordinates:
- Source loading
- Path resolution
- Value preparation
- Command invocation
- Output handling
"""

from __future__ import annotations

import json
import sys
from collections.abc import Callable
from pathlib import Path as PathLib
from typing import TYPE_CHECKING, Any

from data.output import format_shell_output, handle_output
from data.path import Path
from data.source import Source
from data.types import Envelope
from data.value import Value

if TYPE_CHECKING:
    from data.context import Context


def execute_pipeline(  # noqa: PLR0913, C901, PLR0912, PLR0915  # Pipeline orchestration requires complexity per spec
    ctx: Context,
    source_spec: str,
    path_specs: list[str],
    value_specs: list[str],
    command_fn: Callable[..., Any],
    command_name: str,
    output_stdout: bool = False,
    output_stderr: bool = False,
    apply_at_prefix: bool = True,
    command_takes_value: bool = False,
    skip_path_validation: bool = False,
    output_file: str | None = None,
    backup: bool = False,
    force: bool = False,
    quiet: bool = False,
    shell_mode: bool = False,
) -> dict[str, Any]:
    """Execute the pipeline for a command.

    Pipeline steps (per SPEC Section 1):
    1. Parse global options into Context (done by CLI framework)
    2. Parse source spec and load into ctx.data
    3. Parse command args into Path/Value objects
    4. Resolve paths against data (jsonpath-ng)
    5. Prepare all values upfront against original ctx.data
    6. Execute command function per resolved path
    7. Aggregate results from all command invocations
    8. Output result to stdout
    9. Output envelope to stderr

    Args:
        ctx: Context object with shared state
        source_spec: Source specification (file path or stdin)
        path_specs: List of path patterns to resolve
        value_specs: List of value specifications (for SET/APPEND)
        command_fn: Command function to invoke per resolved path
        command_name: Name of the command (for envelope)
        output_stdout: Whether to write results to stdout
        output_stderr: Whether to write envelope to stderr
        apply_at_prefix: Whether to apply --at prefix to paths
        command_takes_value: Whether command function takes value parameter (SET/APPEND style)
        skip_path_validation: Skip path existence check (for SET which creates paths)
        output_file: Optional output file path for writing results
        backup: Whether to create .bak backup before writing
        force: Whether to overwrite existing .bak file
        quiet: Whether to use minimal output (quiet mode)
        shell_mode: Whether to use shell-friendly Rich formatting

    Returns:
        Dictionary with results, status, and exit_code
    """
    try:
        # Step 2: Load source into ctx.data
        source = Source.parse(source_spec)
        try:
            source.load(ctx)
        except FileNotFoundError:
            # For SET, auto-create empty dict if file doesn't exist
            if skip_path_validation:  # SET uses skip_path_validation=True
                ctx.data = {}
                ctx.source = source
            else:
                raise

        # Step 3: Parse command args into Path/Value objects
        # For GET, ignore --at prefix; for SET/APPEND/DELETE, apply it
        # Apply prefix to patterns if needed
        if apply_at_prefix:
            # Create Path with context to get prepared pattern with prefix
            prepared_specs = []
            for spec in path_specs:
                temp_path = Path(spec, ctx)
                prepared_specs.append(temp_path.prepared())
            paths = [Path(spec) for spec in prepared_specs]
        else:
            # No prefix for GET
            paths = [Path(spec) for spec in path_specs]

        # Step 4: Resolve paths against data
        # This returns list of (query, resolved_path) tuples for each path
        all_resolved = []
        if skip_path_validation:
            # For SET-style commands, don't validate path exists - just convert to glom format
            for path_obj in paths:
                all_resolved.append((path_obj.pattern, path_obj.to_glom()))
        else:
            for path_obj in paths:
                resolved = path_obj.resolve(ctx.data)
                all_resolved.extend(resolved)

        # Step 5: Prepare all values upfront (against original ctx.data)
        # Values are prepared BEFORE any command execution
        # This ensures @self:// references see the original data
        prepared_values = [Value.parse(spec, ctx).prepared() for spec in value_specs]

        # Step 6: Execute command function per resolved path
        # One invocation per (path, value) pair
        # For GET: one invocation per resolved path
        # For SET/APPEND: one invocation per (path, value) pair
        results = []

        if value_specs and command_takes_value:
            # Commands with values (SET, APPEND): pair each path with each value
            # For now, assume 1:1 mapping (same number of paths and values)
            # or single value applied to all paths
            if len(prepared_values) == 1:
                # Single value applied to all paths
                value = prepared_values[0]
                for query, resolved_path in all_resolved:
                    result = command_fn(query, resolved_path, value, ctx.data)
                    results.append(result)
            elif len(all_resolved) == len(prepared_values):
                # 1:1 mapping of paths to values
                for (query, resolved_path), value in zip(all_resolved, prepared_values, strict=False):
                    result = command_fn(query, resolved_path, value, ctx.data)
                    results.append(result)
            else:
                # Mismatch - apply each value to each path
                for query, resolved_path in all_resolved:
                    for value in prepared_values:
                        result = command_fn(query, resolved_path, value, ctx.data)
                        results.append(result)
        else:
            # Commands without values (GET, DELETE, DIFF)
            for query, resolved_path in all_resolved:
                result = command_fn(query, resolved_path, ctx.data)
                results.append(result)

        # Step 7: Handle file output (writeback, output-file, backup)
        output_path = PathLib(output_file) if output_file else None
        handled_data = handle_output(
            ctx=ctx,
            output_file=output_path,
            backup=backup,
            force=force,
            quiet=quiet,
        )

        # Step 8: Aggregate results for output
        output = {"results": results, "status": "SUCCESS", "exit_code": 0}

        # Step 9: Output result to stdout
        if output_stdout:
            # Handle shell mode vs JSON mode
            if shell_mode:
                # Shell mode: Rich-formatted raw values
                values = [r.get("value", r) for r in results]
                format_shell_output(values)
            elif handled_data is not None:
                # Normal mode: JSON output
                print(json.dumps(output), file=sys.stdout)  # noqa: T201  # Pipeline outputs to stdout per spec

        # Step 10: Output envelope to stderr
        if output_stderr:
            envelope = Envelope.success(command_name, {"count": len(results)})
            if quiet:
                print(envelope.to_quiet(), file=sys.stderr)  # noqa: T201  # Quiet envelope
            else:
                print(envelope.to_json(), file=sys.stderr)  # noqa: T201  # Full envelope

        return output

    except Exception as e:
        # Failure case
        output = {"results": [], "status": "FAIL", "exit_code": 1, "error": str(e)}

        if output_stderr:
            envelope = Envelope.failure(command_name, str(e))
            print(envelope.to_json(), file=sys.stderr)  # noqa: T201  # Pipeline outputs envelope to stderr per spec

        # Re-raise the exception for the caller to handle
        raise
