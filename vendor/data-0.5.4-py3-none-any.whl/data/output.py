"""Output handling for data CLI."""

from __future__ import annotations

import contextlib
import json
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Any

import anyconfig
from rich.console import Console

from data.exceptions import BackupError
from data.source import FileSource

if TYPE_CHECKING:
    from data.context import Context


def save_file(path: Path, data: Any, backup: bool = False, force: bool = False) -> None:
    """Save data to file using anyconfig.

    Args:
        path: File path to save to.
        data: Data to save.
        backup: Whether to create backup before writing.
        force: Whether to overwrite existing backup.

    Raises:
        BackupError: If backup creation fails.
    """
    # Create backup if requested and file exists
    if backup and path.exists():
        create_backup(path, force=force)

    # Auto-create parent directory if needed
    path.parent.mkdir(parents=True, exist_ok=True)

    # Handle auto-create: if file doesn't exist, create with empty dict first
    if not path.exists():
        with contextlib.suppress(Exception):
            anyconfig.dump({}, str(path))

    # Save data using anyconfig
    anyconfig.dump(data, str(path))


def create_backup(path: Path, force: bool = False) -> None:
    """Create backup of file.

    Args:
        path: File to backup.
        force: Whether to overwrite existing backup.

    Raises:
        BackupError: If backup already exists and force=False, or if file doesn't exist.
    """
    if not path.exists():
        raise BackupError(str(path))

    backup_path = Path(str(path) + ".bak")

    # Check if backup already exists
    if backup_path.exists() and not force:
        raise BackupError(f"Backup file already exists: {backup_path}")

    # Copy file to backup
    try:
        shutil.copy2(path, backup_path)
    except Exception as e:
        raise BackupError(str(path)) from e


def handle_output(
    ctx: Context,
    output_file: Path | None = None,
    backup: bool = False,
    force: bool = False,
    quiet: bool = False,
) -> Any | None:
    """Handle output based on options.

    Args:
        ctx: Context with data and source.
        output_file: Optional output file path.
        backup: Whether to create backup.
        force: Whether to overwrite existing backup.
        quiet: Whether to suppress stdout.

    Returns:
        Data for stdout, or None if suppressed.
    """
    # Determine what to write and where
    if output_file:
        # Write to output file
        save_file(output_file, ctx.data, backup=backup, force=force)
        # In quiet mode with output file, suppress stdout
        if quiet:
            return None
        return ctx.data
    if ctx.source and ctx.source.can_writeback:
        # Write back to source file
        if isinstance(ctx.source, FileSource):
            save_file(Path(ctx.source.path), ctx.data, backup=backup, force=force)
        return ctx.data
    # Non-writable source or stdin - stdout only
    return ctx.data


def format_shell_output(values: list[Any]) -> None:
    """Format values for shell output using Rich.

    Args:
        values: Values to format and print.
    """
    console = Console()
    for value in values:
        if isinstance(value, dict | list):
            # Complex objects: JSON encode
            console.print(json.dumps(value))
        else:
            # Simple values: print directly
            console.print(value)
