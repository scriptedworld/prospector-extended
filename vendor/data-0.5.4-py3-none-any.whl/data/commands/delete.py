"""DELETE command - remove values at paths.

This module provides the delete() function which uses glom to remove
values at paths in nested data structures.
"""

from __future__ import annotations

from typing import Any

from glom import delete as glom_delete


def delete(query: str, path: str, data: Any) -> Any:
    """Remove value at path from data.

    Uses glom to delete the value at the given path in the data structure.
    The path is already resolved by the pipeline (no wildcards).

    Args:
        query: Original query pattern (e.g., "$.name")
        path: Resolved path for glom (e.g., "name")
        data: Data structure to modify

    Returns:
        The modified data object (same reference, mutated in place).
        For root deletion, returns {}.

    Example:
        >>> delete("$.name", "name", {"name": "alice", "age": 30})
        {'age': 30}
    """
    # Root deletion - return empty dict/list
    if not path or path in ("$", "."):
        if isinstance(data, dict | list):
            data.clear()
        return data

    # Delete the path using glom
    glom_delete(data, path)
    return data
