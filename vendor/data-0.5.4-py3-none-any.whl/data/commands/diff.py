"""DIFF command - compare values for differences.

This module provides the diff() function which uses DeepDiff to compare
values and return a list of differences.
"""

from __future__ import annotations

from typing import Any

from deepdiff import DeepDiff

# DeepDiff output keys grouped by structure type
_CHANGE_KEYS = ("values_changed", "type_changes")  # Have old_value/new_value
_ADDED_KEYS = ("dictionary_item_added", "iterable_item_added")  # Left is None
_REMOVED_KEYS = ("dictionary_item_removed", "iterable_item_removed")  # Right is None


def _process_changes(dd: DeepDiff, differences: list[dict[str, Any]]) -> None:
    """Process value/type changes from DeepDiff output."""
    for key in _CHANGE_KEYS:
        if key in dd:
            for path_str, change in dd[key].items():
                differences.append({"path": path_str, "left": change["old_value"], "right": change["new_value"]})


def _process_additions(dd: DeepDiff, differences: list[dict[str, Any]]) -> None:
    """Process added items from DeepDiff output."""
    for key in _ADDED_KEYS:
        if key in dd:
            for path_str, value in dd[key].items():
                differences.append({"path": path_str, "left": None, "right": value})


def _process_removals(dd: DeepDiff, differences: list[dict[str, Any]]) -> None:
    """Process removed items from DeepDiff output."""
    for key in _REMOVED_KEYS:
        if key in dd:
            for path_str, value in dd[key].items():
                differences.append({"path": path_str, "left": value, "right": None})


def diff(
    query: str,
    path: str,
    left_value: Any,
    right_value: Any,
    ignore: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Compare left_value with right_value for differences.

    Uses DeepDiff to detect and report differences between values.
    Returns a list of difference entries with path, left, and right values.

    Args:
        query: Original query pattern (e.g., "$.config")
        path: Resolved path for the left value
        left_value: Value at the left path
        right_value: Value to compare against
        ignore: Optional list of paths to ignore in comparison

    Returns:
        List of difference dicts: [{"path": ..., "left": ..., "right": ...}]
        Empty list if values are identical.

    Example:
        >>> diff("$", "", {"a": 1}, {"a": 2})
        [{'path': 'root.a', 'left': 1, 'right': 2}]
    """
    dd = DeepDiff(
        left_value,
        right_value,
        ignore_order=False,
        exclude_paths=set(ignore) if ignore else None,
        verbose_level=2,
    )

    if not dd:
        return []

    differences: list[dict[str, Any]] = []
    _process_changes(dd, differences)
    _process_additions(dd, differences)
    _process_removals(dd, differences)

    return differences
