"""Commands package for data manipulation.

Contains simple command functions that use glom for data access.
Each command is called by the pipeline per resolved path.
"""

from __future__ import annotations

__all__ = ["append", "delete", "diff", "get", "set"]

from data.commands.append import append
from data.commands.delete import delete
from data.commands.diff import diff
from data.commands.get import get
from data.commands.set import set
