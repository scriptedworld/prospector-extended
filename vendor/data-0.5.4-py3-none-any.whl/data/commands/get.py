"""GET command - retrieve values from data at resolved paths.

This module provides the get() function which uses glom to access
values in nested data structures.
"""

from __future__ import annotations

from typing import Any

from glom import glom


def get(query: str, path: str, data: Any) -> dict[str, Any]:
    """Retrieve value at path from data.

    Uses glom to access the value at the given path in the data structure.
    The path is already resolved by the pipeline (no wildcards).

    Args:
        query: Original query pattern (e.g., "$.name")
        path: Resolved path for glom (e.g., "name")
        data: Data structure to query

    Returns:
        Dict with query, path, and value keys:
        {"query": query, "path": path, "value": <retrieved_value>}

    Example:
        >>> get("$.name", "name", {"name": "alice"})
        {'query': '$.name', 'path': 'name', 'value': 'alice'}
    """
    # Empty path means root - return entire data
    value = data if not path else glom(data, path)
    return {"query": query, "path": path, "value": value}
