"""APPEND command - append values to arrays.

This module provides the append() function which uses glom to append
values to arrays in nested data structures.
"""

from __future__ import annotations

from typing import Any

from glom import Assign, glom

from data.exceptions import PathError


def append(query: str, path: str, value: Any, data: Any) -> Any:
    """Append value to array at path.

    Uses glom to access the array at the given path, then appends the value.
    The path is already resolved by the pipeline (no wildcards).
    The value is already prepared by the pipeline.

    Args:
        query: Original query pattern (e.g., "$.arr")
        path: Resolved path for glom (e.g., "arr")
        value: Value to append (already prepared)
        data: Data structure to modify

    Returns:
        The modified data object (same reference, mutated in place)

    Raises:
        PathError: If target is not an array

    Example:
        >>> append("$.arr", "arr", 4, {"arr": [1, 2, 3]})
        {'arr': [1, 2, 3, 4]}
    """
    # Get the array at path, or create it if it doesn't exist
    try:
        target = glom(data, path) if path else data
    except Exception:
        # Path doesn't exist - create empty array
        if path:
            spec = Assign(path, [])
            data = glom(data, spec)
            target = glom(data, path)
        else:  # pragma: no cover
            # Root path doesn't exist - cannot happen: glom only throws when path is truthy
            raise PathError(path, "Cannot append to non-existent root") from None

    # Validate target is an array
    if not isinstance(target, list):
        raise PathError(path, f"Target is not an array: got {type(target).__name__}")

    # Append the value
    target.append(value)

    return data
