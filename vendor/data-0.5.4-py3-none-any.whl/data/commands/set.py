"""SET command - assign values to data at resolved paths.

This module provides the set() function which uses glom to modify
values in nested data structures.
"""

from __future__ import annotations

from typing import Any

from glom import Assign, glom


def set(query: str, path: str, value: Any, data: Any) -> Any:
    """Set value at path in data.

    Uses glom to assign the value at the given path in the data structure.
    The path is already resolved by the pipeline (no wildcards).

    Args:
        query: Original query pattern (e.g., "$.name")
        path: Resolved path for glom (e.g., "name")
        value: Prepared value to assign
        data: Data structure to modify

    Returns:
        The modified data structure (same object, mutated in place)

    Example:
        >>> set("$.name", "name", "alice", {})
        {'name': 'alice'}
    """
    glom(data, Assign(path, value, missing=dict))
    return data
