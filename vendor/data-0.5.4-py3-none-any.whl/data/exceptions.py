"""Exception hierarchy for Data CLI.

This module provides structured error handling with specific exception types
for different error conditions.
"""

from __future__ import annotations


class DataError(Exception):
    """Base exception for all Data CLI errors."""

    pass


class ParseError(DataError):
    """Error parsing source file.

    Attributes:
        source: Source file path or identifier.
        line: Line number where error occurred.
        column: Column number where error occurred.
    """

    def __init__(self, source: str, line: int, column: int) -> None:
        """Initialize ParseError.

        Args:
            source: Source file path.
            line: Line number.
            column: Column number.
        """
        super().__init__(f"Parse error in {source} at line {line}, column {column}")
        self.source = source
        self.line = line
        self.column = column


class PathError(DataError):
    """Error resolving or accessing path in document.

    Attributes:
        path: The path that caused the error.
        message: Descriptive error message.
    """

    def __init__(self, path: str, message: str) -> None:
        """Initialize PathError.

        Args:
            path: The problematic path.
            message: Error description.
        """
        super().__init__(f"Path error at '{path}': {message}")
        self.path = path
        self.message = message


class ReferenceError(DataError):
    """Error resolving file or self reference.

    Attributes:
        ref: The reference string that caused the error.
        message: Descriptive error message.
    """

    def __init__(self, ref: str, message: str) -> None:
        """Initialize ReferenceError.

        Args:
            ref: The problematic reference.
            message: Error description.
        """
        super().__init__(f"Reference error '{ref}': {message}")
        self.ref = ref
        self.message = message


class SchemaError(DataError):
    """Schema validation error.

    Attributes:
        path: JSONPath where validation failed.
        message: Validation error description.
    """

    def __init__(self, path: str, message: str) -> None:
        """Initialize SchemaError.

        Args:
            path: Path where validation failed.
            message: Validation error description.
        """
        super().__init__(f"Schema error at '{path}': {message}")
        self.path = path
        self.message = message


class BackupError(DataError):
    """Error creating or managing backup files.

    Attributes:
        path: Backup file path.
    """

    def __init__(self, path: str) -> None:
        """Initialize BackupError.

        Args:
            path: Backup file path.
        """
        super().__init__(f"Backup error for '{path}'")
        self.path = path
