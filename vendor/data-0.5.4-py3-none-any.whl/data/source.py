"""Source classes for data loading."""

from __future__ import annotations

import sys
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

import anyconfig
from jsonpath_ng import parse as jsonpath_parse

from data.exceptions import ParseError
from data.types import DataFormat

if TYPE_CHECKING:
    from data.context import Context


class Source(ABC):
    """Abstract base class for data sources."""

    @staticmethod
    def parse(spec: str) -> Source:
        """Parse source specification into Source instance.

        Args:
            spec: Source specification string.

        Returns:
            Parsed Source instance.

        Examples:
            >>> Source.parse("data.json")  # FileSource, JSON
            >>> Source.parse("json://data.json")  # FileSource, JSON
            >>> Source.parse("yaml://config.yaml")  # FileSource, YAML
            >>> Source.parse("-")  # StdinSource, JSON
            >>> Source.parse("data.json#items")  # FileSource with extraction
        """
        # Check for extraction (# delimiter)
        extraction: str | None = None
        if "#" in spec:
            spec, extraction = spec.split("#", 1)

        # Check for stdin
        if spec == "-" or spec.endswith("://-"):
            # Stdin source
            format_str = "json"  # default
            if spec.startswith("json://"):
                format_str = "json"
            elif spec.startswith("yaml://"):
                format_str = "yaml"
            elif spec.startswith("toml://"):
                format_str = "toml"

            return StdinSource(DataFormat(format_str), extraction)

        # File source - check for format scheme
        format_str = "json"  # default
        path = spec

        if "://" in spec:
            scheme, path = spec.split("://", 1)
            format_str = scheme

        return FileSource(path, DataFormat(format_str), extraction)

    @abstractmethod
    def load(self, ctx: Context) -> None:
        """Load data from source into context.

        Args:
            ctx: Context to load data into.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def can_writeback(self) -> bool:
        """Check if source supports writeback.

        Returns:
            True if writeback is supported.
        """
        raise NotImplementedError

    def _validate_data(self, data: Any, source_name: str) -> None:
        """Validate loaded data for reserved keys.

        Args:
            data: Loaded data to validate.
            source_name: Source identifier for error messages.

        Raises:
            ParseError: If data contains reserved key ".".
        """
        if isinstance(data, dict) and "." in data:
            # Create ParseError with custom message about reserved key
            exc = ParseError(source_name, 0, 0)
            exc.args = (f"Parse error in {source_name} at line 0, column 0: '.' is a reserved key",)
            raise exc

    def _apply_extraction(self, data: Any, extraction: str, ctx: Context) -> Any:
        """Apply extraction path to loaded data.

        Args:
            data: Full loaded data.
            extraction: JSONPath extraction pattern.
            ctx: Context with original data.

        Returns:
            Extracted subtree.
        """
        # Emit warning to stderr
        print("Warning: extraction applied, writeback disabled", file=sys.stderr)  # noqa: T201

        # Normalize extraction pattern (ensure it starts with $ if not a simple key)
        if not extraction.startswith("$") and not extraction.startswith("."):
            extraction = f"$.{extraction}"

        jsonpath_expr = jsonpath_parse(extraction)
        matches = jsonpath_expr.find(data)

        # Return first match value, or original data if no match
        if matches:
            return matches[0].value

        return data


class FileSource(Source):
    """File-based data source."""

    def __init__(self, path: str, format: DataFormat, extraction: str | None = None) -> None:
        """Initialize FileSource.

        Args:
            path: File path.
            format: Data format.
            extraction: Optional extraction path.
        """
        self.path = path
        self.format = format
        self.extraction = extraction

    def load(self, ctx: Context) -> None:
        """Load data from file.

        Args:
            ctx: Context to populate.

        Raises:
            FileNotFoundError: If file doesn't exist.
            ParseError: If file has invalid syntax or reserved keys.
        """
        try:
            # Load using anyconfig
            data = anyconfig.load(self.path, ac_parser=self.format.value)  # type: ignore[no-untyped-call]
        except FileNotFoundError:
            raise
        except Exception as e:
            # Wrap other exceptions as ParseError
            raise ParseError(self.path, 0, 0) from e

        # Validate no "." key
        self._validate_data(data, self.path)

        # Apply extraction if specified
        if self.extraction:
            ctx.data = data  # Temporarily set for Path resolution
            data = self._apply_extraction(data, self.extraction, ctx)

        # Store in context
        ctx.data = data
        ctx.source = self

    @property
    def can_writeback(self) -> bool:
        """Check if writeback is supported.

        Returns:
            True if no extraction, False if extraction applied.
        """
        return self.extraction is None


class StdinSource(Source):
    """Stdin-based data source."""

    def __init__(self, format: DataFormat, extraction: str | None = None) -> None:
        """Initialize StdinSource.

        Args:
            format: Data format.
            extraction: Optional extraction path.
        """
        self.format = format
        self.extraction = extraction

    def load(self, ctx: Context) -> None:
        """Load data from stdin.

        Args:
            ctx: Context to populate.

        Raises:
            ParseError: If stdin has invalid syntax or reserved keys.
        """
        try:
            # Read from stdin and load using anyconfig
            stdin_content = sys.stdin.read()
            data = anyconfig.loads(stdin_content, ac_parser=self.format.value)  # type: ignore[no-untyped-call]
        except Exception as e:
            raise ParseError("<stdin>", 0, 0) from e

        # Validate no "." key
        self._validate_data(data, "<stdin>")

        # Apply extraction if specified
        if self.extraction:
            ctx.data = data  # Temporarily set for Path resolution
            data = self._apply_extraction(data, self.extraction, ctx)

        # Store in context
        ctx.data = data
        ctx.source = self

    @property
    def can_writeback(self) -> bool:
        """Check if writeback is supported.

        Returns:
            Always False for stdin.
        """
        return False
