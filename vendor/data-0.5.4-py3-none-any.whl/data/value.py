"""Value classes for parsing and preparing command arguments."""

from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

import anyconfig
from jsonpath_ng import parse as jsonpath_parse

from data.exceptions import ReferenceError

if TYPE_CHECKING:
    from data.context import Context


class Value(ABC):
    """Abstract base class for values."""

    @staticmethod
    def parse(raw: str, ctx: Context) -> Value:
        """Parse a raw string into a Value instance.

        Args:
            raw: Raw string to parse.
            ctx: Context for resolution.

        Returns:
            Appropriate Value subclass instance.
        """
        # Check for @self:// pattern (self-reference)
        if raw.startswith("@self://"):
            path = raw[8:]  # Remove "@self://" prefix
            return SelfRefValue(path, ctx)

        # Check for @file patterns (file reference)
        if raw.startswith("@"):
            # Extract format hint if present (@file+yaml://, @file+toml://, etc.)
            format_match = re.match(r"^@file\+(yaml|toml|json)://(.+)$", raw)
            if format_match:
                format_hint = format_match.group(1)
                path_and_extraction = format_match.group(2)
            elif raw.startswith("@file://"):
                format_hint = None
                path_and_extraction = raw[8:]  # Remove "@file://" prefix
            else:
                # Plain @filename
                format_hint = None
                path_and_extraction = raw[1:]  # Remove "@" prefix

            # Check for extraction (delimiter is #)
            if "#" in path_and_extraction:
                path, extraction = path_and_extraction.split("#", 1)
            else:
                path = path_and_extraction
                extraction = None

            return FileRefValue(path, format_hint, extraction)

        # Everything else is a literal value
        return LiteralValue(raw)

    @abstractmethod
    def prepared(self) -> Any:
        """Prepare the value for use.

        Returns:
            Prepared value.
        """


class LiteralValue(Value):
    """Literal inline value."""

    def __init__(self, raw: str) -> None:
        """Initialize literal value.

        Args:
            raw: Raw string value.
        """
        self.raw = raw

    def prepared(self) -> Any:
        """Prepare literal value.

        Returns:
            Prepared value (parsed as JSON or plain string).
        """
        # Try to parse as JSON
        try:
            return json.loads(self.raw)
        except (json.JSONDecodeError, ValueError):
            # If not valid JSON, return as plain string
            return self.raw


class FileRefValue(Value):
    """File reference value (@file://...)."""

    def __init__(self, path: str, format_hint: str | None = None, extraction: str | None = None) -> None:
        """Initialize file reference value.

        Args:
            path: File path.
            format_hint: Optional format hint (json, yaml, toml).
            extraction: Optional extraction path.
        """
        self.path = path
        self.format_hint = format_hint
        self.extraction = extraction

    def prepared(self) -> Any:
        """Prepare file reference value.

        Returns:
            Loaded and optionally extracted value.

        Raises:
            ReferenceError: If file doesn't exist or extraction path not found.
        """
        # Determine format (default to JSON if no hint provided)
        format_str = self.format_hint if self.format_hint else "json"

        # Load file using anyconfig
        try:
            data = anyconfig.load(self.path, ac_parser=format_str)  # type: ignore[no-untyped-call]
        except FileNotFoundError as e:
            raise ReferenceError(f"@{self.path}", f"File not found: {self.path}") from e
        except Exception as e:
            raise ReferenceError(f"@{self.path}", f"Failed to load file: {e}") from e

        # Apply extraction if specified
        if self.extraction:
            # Normalize extraction pattern (using jsonpath_ng, ignoring at_prefix - always explicit)
            extraction_pattern = self.extraction
            if not extraction_pattern.startswith("$") and not extraction_pattern.startswith("."):
                extraction_pattern = f"$.{extraction_pattern}"

            try:
                jsonpath_expr = jsonpath_parse(extraction_pattern)
                matches = jsonpath_expr.find(data)

                if not matches:
                    raise ReferenceError(
                        f"@{self.path}#{self.extraction}",
                        f"Extraction path not found: {self.extraction}",
                    )

                # Return first match value
                return matches[0].value
            except Exception as e:
                if isinstance(e, ReferenceError):
                    raise
                raise ReferenceError(
                    f"@{self.path}#{self.extraction}",
                    f"Extraction failed: {e}",
                ) from e

        return data


class SelfRefValue(Value):
    """Self-reference value (@self://...)."""

    def __init__(self, path: str, ctx: Context) -> None:
        """Initialize self-reference value.

        Args:
            path: Extraction path.
            ctx: Context with data.
        """
        self.path = path
        self.ctx = ctx

    def prepared(self) -> Any:
        """Prepare self-reference value.

        Returns:
            Extracted value from ctx.data.

        Raises:
            ReferenceError: If extraction path not found in ctx.data.
        """
        # Normalize extraction pattern (using jsonpath_ng, ignoring at_prefix - always explicit)
        extraction_pattern = self.path
        if not extraction_pattern.startswith("$") and not extraction_pattern.startswith("."):
            extraction_pattern = f"$.{extraction_pattern}"

        try:
            jsonpath_expr = jsonpath_parse(extraction_pattern)
            matches = jsonpath_expr.find(self.ctx.data)

            if not matches:
                raise ReferenceError(
                    f"@self://{self.path}",
                    f"Path not found in context data: {self.path}",
                )

            # Return first match value
            return matches[0].value
        except Exception as e:
            if isinstance(e, ReferenceError):
                raise
            raise ReferenceError(
                f"@self://{self.path}",
                f"Extraction failed: {e}",
            ) from e
