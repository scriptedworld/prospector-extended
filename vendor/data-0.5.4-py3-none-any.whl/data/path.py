"""Path class for JSONPath pattern resolution.

This module provides the Path class for resolving JSONPath patterns to actual
paths in a document structure. Uses jsonpath-ng for pattern matching.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from jsonpath_ng import parse as jsonpath_parse
from jsonpath_ng.exceptions import JsonPathParserError
from jsonpath_ng.jsonpath import Child, Fields, Index, JSONPath

from data.exceptions import PathError

if TYPE_CHECKING:
    from data.context import Context


def _tree_to_glom(node: JSONPath) -> str:
    """Convert a jsonpath-ng tree node to a glom-compatible dot path.

    Walks the structured tree (Child, Fields, Index nodes) to build
    the path, e.g. Child(Fields('arr'), Index(-1)) -> "arr.-1".

    Args:
        node: A jsonpath-ng path node.

    Returns:
        Glom-compatible dot path. Empty string means root.
    """
    parts: list[str] = []
    _collect_parts(node, parts)
    return ".".join(parts)


def _collect_parts(node: JSONPath, parts: list[str]) -> None:
    """Recursively collect glom path segments from a jsonpath-ng tree node."""
    if isinstance(node, Child):
        _collect_parts(node.left, parts)
        _collect_parts(node.right, parts)
    elif isinstance(node, Fields):
        parts.extend(node.fields)
    elif isinstance(node, Index):
        parts.append(str(node.indices[0]))


class Path:
    """JSONPath pattern resolver.

    Resolves JSONPath patterns to actual paths in a document. Returns
    (query, path) tuples WITHOUT retrieving values. Commands use glom
    separately to access values.

    Attributes:
        pattern: The JSONPath pattern to resolve.
        context: Optional context for at_prefix support.
    """

    def __init__(self, pattern: str, context: Context | None = None) -> None:
        """Initialize Path with pattern and optional context.

        Args:
            pattern: JSONPath pattern string.
            context: Optional context for at_prefix support.

        Raises:
            PathError: If pattern is invalid.
        """
        self.pattern = pattern
        self.context = context

        normalized = self._normalize_pattern(pattern)
        try:
            self._parsed: JSONPath = jsonpath_parse(normalized)
        except (JsonPathParserError, Exception) as e:
            raise PathError(pattern, f"Invalid pattern: {e}") from e

    def resolve(self, data: object) -> list[tuple[str, str]]:
        """Resolve pattern to list of (query, path) tuples.

        Args:
            data: Document data to resolve paths against.

        Returns:
            List of (query, path) tuples where:
            - query is the original user pattern (for traceability)
            - path is the resolved absolute path (for glom operations)

        Raises:
            PathError: If literal path not found (wildcards return empty list).
        """
        try:
            matches = self._parsed.find(data)
        except Exception as e:
            raise PathError(self.pattern, f"Resolution failed: {e}") from e

        if not matches:
            if self._is_wildcard_pattern():
                return []
            raise PathError(self.pattern, "Path not found in document")

        return [(self.pattern, _tree_to_glom(match.full_path)) for match in matches]

    def to_glom(self) -> str:
        """Convert the parsed pattern to a glom-compatible dot path.

        Walks the jsonpath-ng parse tree to build the path.

        Returns:
            Glom-compatible dot path (e.g., "arr.-1", "a.b.0.c").
            Empty string means root.
        """
        return _tree_to_glom(self._parsed)

    def prepared(self) -> str:
        """Prepare pattern with at_prefix applied.

        Returns:
            Pattern with at_prefix prepended.
        """
        prefix = "$" if self.context is None else self.context.at_prefix

        # Normalize the pattern first
        normalized = self._normalize_pattern(self.pattern)

        # If prefix is just "$", prepend it with a dot for simple names
        # If prefix is longer like "$.user", append the pattern properly
        if prefix == "$":
            if normalized.startswith("$"):
                return normalized
            return f"$.{normalized}" if not normalized.startswith(".") else f"${normalized}"

        # For prefixes like "$.user", append the pattern
        if normalized.startswith("$"):
            # Pattern already has root, replace it with prefix
            return prefix + normalized[1:]
        if normalized.startswith("."):
            # Pattern has leading dot, append after prefix
            return prefix + normalized
        # Pattern has no dot, add one
        return f"{prefix}.{normalized}"

    def _normalize_pattern(self, pattern: str) -> str:
        """Normalize pattern to standard JSONPath format.

        Args:
            pattern: Raw pattern string.

        Returns:
            Normalized pattern starting with $.
        """
        if pattern in (".", "$"):
            return "$"

        if pattern.startswith("$"):
            return pattern
        if pattern.startswith("."):
            return "$" + pattern

        return f"$.{pattern}"

    def _is_wildcard_pattern(self) -> bool:
        """Check if pattern contains wildcards or slicing.

        Returns:
            True if pattern contains wildcards, slicing, or recursive descent.
        """
        normalized = self._normalize_pattern(self.pattern)
        return any(marker in normalized for marker in ["*", "[:", ":]", "..", "',"])
