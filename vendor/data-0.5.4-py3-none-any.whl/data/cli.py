"""CLI implementation with Click framework.

This module provides the main CLI entry point and command routing.
"""

from __future__ import annotations

import json
import sys
from collections.abc import Callable
from itertools import zip_longest
from pathlib import Path as PathLib
from typing import Any

import click
import yaml

from data.commands.append import append as append_command
from data.commands.delete import delete as delete_command
from data.commands.diff import diff as diff_command
from data.commands.get import get as get_command
from data.commands.set import set as set_command
from data.context import Context
from data.output import format_shell_output
from data.pipeline import execute_pipeline
from data.source import Source
from data.value import Value


class SourceFirstGroup(click.Group):
    """Custom group that takes SOURCE as first positional argument.

    This allows the CLI pattern: data SOURCE CMD ARGS [OPTIONS]
    instead of: data CMD SOURCE ARGS [OPTIONS]
    """

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        """Extract SOURCE from first position if it's not a command name."""
        # If first arg exists and isn't a command, it's SOURCE
        # Note: "-" is stdin (valid source), not an option flag
        if args and args[0] not in self.commands:
            first_arg = args[0]
            # It's a source if it's "-" (stdin) or doesn't start with "-" (file path)
            if first_arg == "-" or not first_arg.startswith("-"):
                ctx.ensure_object(dict)
                ctx.obj["source"] = first_arg
                args = args[1:]
        return super().parse_args(ctx, args)


def common_options(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Base options for all commands."""
    fn = click.option("--quiet", "-q", is_flag=True, help="Minimal output")(fn)
    fn = click.option("--shell", "--raw", "-r", is_flag=True, help="Shell-friendly output (Rich formatted)")(fn)
    return click.option("--output-file", "-o", type=click.Path(), help="Write to file")(fn)


def reader_options(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Options for GET (read with --at support)."""
    fn = common_options(fn)
    return click.option("--at", default="$", help="Prefix for paths (default: $)")(fn)


def writer_options(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Options for SET, APPEND, DELETE (read + write)."""
    fn = reader_options(fn)
    fn = click.option("--backup", is_flag=True, help="Create .bak before write")(fn)
    return click.option("--force", is_flag=True, help="Overwrite existing .bak")(fn)


@click.group(cls=SourceFirstGroup)
@click.pass_context
def main(ctx: click.Context) -> None:
    """CLI tool for JSON, YAML, and TOML manipulation."""
    ctx.ensure_object(dict)


@main.command()
@click.argument("paths", nargs=-1)
@reader_options
@click.pass_context
def get(  # noqa: PLR0913
    ctx: click.Context,
    paths: tuple[str, ...],
    at: str,
    quiet: bool,
    shell: bool,
    output_file: str | None,
) -> None:
    r"""Retrieve values from structured data.

    PATHS are JSONPath expressions to retrieve (default: root).

    \b
    Path Syntax:
      Simple paths:
        data file.json get name                  # dict key
        data file.json get a.b.c                 # nested keys
        data file.json get $                     # root (default)
    \b
      Array indexing:
        data file.json get arr[0]                # first element
        data file.json get arr[-1]               # last element
        data file.json get arr[0,2,5]            # multi-index
    \b
      Wildcards:
        data file.json get arr[*]                # all array elements
        data file.json get ..name                # recursive (all "name" at any depth)
    \b
      Slicing:
        data file.json get arr[1:4]              # range (indices 1,2,3)
        data file.json get arr[-3:]              # last 3 elements
        data file.json get arr[::2]              # every other element
        data file.json get arr[1:6:2]            # range with step
    \b
      Property subsets:
        data file.json get "obj['a','b']"        # select specific keys
    \b
      Special characters in keys:
        data file.json get '.["x-y"]'            # keys with hyphens, dots, etc.
    \b
      Scoped access with --at:
        data file.json get name --at '$.user'    # equivalent to $.user.name
    """
    source = ctx.obj.get("source")
    if not source:
        click.echo("Error: SOURCE required", err=True)
        sys.exit(1)

    data_ctx = Context(at_prefix=at)

    # If no paths specified, get root
    path_list = list(paths) if paths else ["$"]

    try:
        execute_pipeline(
            ctx=data_ctx,
            source_spec=source,
            path_specs=path_list,
            value_specs=[],
            command_fn=get_command,
            command_name="get",
            output_stdout=True,
            output_stderr=True,
            apply_at_prefix=False,  # GET ignores --at prefix
            command_takes_value=False,
            output_file=output_file,
            backup=False,
            force=False,
            quiet=quiet,
            shell_mode=shell,
        )
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command("set")
@click.argument("path_values", nargs=-1)
@writer_options
@click.pass_context
def set_cmd(  # noqa: PLR0913
    ctx: click.Context,
    path_values: tuple[str, ...],
    at: str,
    quiet: bool,
    shell: bool,
    output_file: str | None,
    backup: bool,
    force: bool,
) -> None:
    r"""Set values in structured data.

    PATH_VALUES are path value pairs (path1 value1 path2 value2 ...).

    \b
    Path Syntax:
      Simple paths:
        data file.json set name "hello"              # dict key
        data file.json set a.b.c "hello"             # nested keys
    \b
      Array indexing:
        data file.json set arr[0] "hello"            # first element
        data file.json set arr[-1] "hello"           # last element
        data file.json set arr[0,2,5] "hello"        # multi-index
    \b
      Wildcards:
        data file.json set arr[*] "hello"            # all array elements
        data file.json set ..name "hello"            # recursive (all "name" at any depth)
    \b
      Slicing:
        data file.json set arr[1:4] "hello"          # range (indices 1,2,3)
        data file.json set arr[-3:] "hello"          # last 3 elements
        data file.json set arr[::2] "hello"          # every other element
        data file.json set arr[1:6:2] "hello"        # range with step
    \b
      Property subsets:
        data file.json set "obj['a','b']" "hello"    # select specific keys
    \b
      Special characters in keys:
        data file.json set '.["x-y"]' "hello"        # keys with hyphens, dots, etc.
    \b
      Scoped access with --at:
        data file.json set name "hello" --at '$.user' # equivalent to $.user.name
    \b
    Value Types:
      Literal values (parsed as JSON, falls back to string):
        data file.json set name "hello"
        data file.json set count 42
        data file.json set active true
        data file.json set tags '["a","b"]'
        data file.json set user '{"name":"jeff"}'
    \b
      File references (pull value from another file):
        data file.json set key @other.json              # short form (assumes JSON)
        data file.json set key @file://other.json       # explicit form
        data file.json set key @file+yaml://config.yaml # with format hint
        data file.json set key @file+toml://settings.toml
    \b
      File references with extraction (use # to pull a specific path):
        data file.json set version @other.json#version
        data file.json set db_host @file+yaml://config.yaml#database.host
    \b
      Self-references (reference a value from the same file):
        data file.json set backup_name @self://name
        data file.json set summary.total @self://items[*]
    """
    source = ctx.obj.get("source")
    if not source:
        click.echo("Error: SOURCE required", err=True)
        sys.exit(1)

    data_ctx = Context(at_prefix=at)

    # Parse path/value pairs
    if len(path_values) % 2 != 0:
        click.echo("Error: SET requires path value pairs", err=True)
        sys.exit(1)

    paths = list(path_values[::2])  # Every even index (0, 2, 4...)
    values = list(path_values[1::2])  # Every odd index (1, 3, 5...)

    try:
        execute_pipeline(
            ctx=data_ctx,
            source_spec=source,
            path_specs=paths,
            value_specs=values,
            command_fn=set_command,
            command_name="set",
            output_stdout=True,
            output_stderr=True,
            apply_at_prefix=True,  # SET applies --at prefix
            command_takes_value=True,
            skip_path_validation=True,  # SET creates paths, doesn't require existing
            output_file=output_file,
            backup=backup,
            force=force,
            quiet=quiet,
            shell_mode=shell,
        )
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


def _parse_key_value_pairs(arguments: tuple[str, ...], ctx: Context) -> dict[str, Any]:
    """Assemble alternating key-value arguments into a dict with standard value coercion.

    Args:
        arguments: Alternating key-value strings.
        ctx: Context for value parsing.

    Returns:
        Dict assembled from pairs, values coerced via Value.parse (json.loads, fallback to string).

    Raises:
        ValueError: If arguments length is odd (a key has no matching value).
    """
    sentinel = object()
    args_iter = iter(arguments)
    result: dict[str, Any] = {}
    for key, value in zip_longest(args_iter, args_iter, fillvalue=sentinel):
        if value is sentinel:
            raise ValueError(f"Missing value for key '{key}'.")
        result[str(key)] = Value.parse(str(value), ctx).prepared()
    return result


@main.command()
@click.argument("path")
@click.argument("values", nargs=-1)
@click.option("--object", "object_flag", is_flag=True, help="Treat values as key-value pairs and append as a single dict")
@writer_options
@click.pass_context
def append(  # noqa: PLR0913
    ctx: click.Context,
    path: str,
    values: tuple[str, ...],
    object_flag: bool,
    at: str,
    quiet: bool,
    shell: bool,
    output_file: str | None,
    backup: bool,
    force: bool,
) -> None:
    r"""Append values to arrays in structured data.

    PATH is the array to append to.
    VALUES are the values to append.

    \b
    Path Syntax:
      Simple paths:
        data file.json append items "hello"              # dict key
        data file.json append a.b.items "hello"          # nested keys
    \b
      Array indexing:
        data file.json append arr[0] "hello"             # first element (must be array)
        data file.json append arr[-1] "hello"            # last element (must be array)
    \b
      Wildcards:
        data file.json append arr[*] "hello"             # append to all sub-arrays
        data file.json append ..items "hello"            # recursive (all "items" at any depth)
    \b
      Special characters in keys:
        data file.json append '.["my-list"]' "hello"     # keys with hyphens, dots, etc.
    \b
      Scoped access with --at:
        data file.json append items "hello" --at '$.user' # equivalent to $.user.items
    \b
    Value Types:
      Literal values (parsed as JSON, falls back to string):
        data file.json append items "hello"
        data file.json append items 42
        data file.json append items '{"name":"jeff"}'
    \b
      File references (pull value from another file):
        data file.json append items @other.json              # short form (assumes JSON)
        data file.json append items @file://other.json       # explicit form
        data file.json append items @file+yaml://config.yaml # with format hint
        data file.json append items @file+toml://settings.toml
    \b
      File references with extraction (use # to pull a specific path):
        data file.json append items @other.json#version
        data file.json append items @file+yaml://config.yaml#database.host
    \b
      Self-references (reference a value from the same file):
        data file.json append items @self://name
        data file.json append items @self://config.database.host
    """
    source = ctx.obj.get("source")
    if not source:
        click.echo("Error: SOURCE required", err=True)
        sys.exit(1)

    data_ctx = Context(at_prefix=at)

    if not values:
        click.echo("Error: APPEND requires at least one value", err=True)
        sys.exit(1)

    if object_flag:
        try:
            obj = _parse_key_value_pairs(values, data_ctx)
        except ValueError as e:
            click.echo(f"Error: {e}", err=True)
            sys.exit(1)
        value_specs = [json.dumps(obj)]
        path_specs = [path]
    else:
        value_specs = list(values)
        path_specs = [path] * len(values)

    try:
        execute_pipeline(
            ctx=data_ctx,
            source_spec=source,
            path_specs=path_specs,
            value_specs=value_specs,
            command_fn=append_command,
            command_name="append",
            output_stdout=True,
            output_stderr=True,
            apply_at_prefix=True,  # APPEND applies --at prefix
            command_takes_value=True,
            skip_path_validation=True,  # APPEND auto-creates empty array if path doesn't exist
            output_file=output_file,
            backup=backup,
            force=force,
            quiet=quiet,
            shell_mode=shell,
        )
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("paths", nargs=-1)
@writer_options
@click.pass_context
def delete(  # noqa: PLR0913
    ctx: click.Context,
    paths: tuple[str, ...],
    at: str,
    quiet: bool,
    shell: bool,
    output_file: str | None,
    backup: bool,
    force: bool,
) -> None:
    r"""Delete values from structured data.

    PATHS are the paths to delete.

    \b
    Path Syntax:
      Simple paths:
        data file.json delete name                   # dict key
        data file.json delete a.b.c                  # nested keys
    \b
      Array indexing:
        data file.json delete arr[0]                 # first element
        data file.json delete arr[-1]                # last element
        data file.json delete arr[0,2,5]             # multi-index
    \b
      Wildcards:
        data file.json delete arr[*]                 # all array elements
        data file.json delete ..name                 # recursive (all "name" at any depth)
    \b
      Slicing:
        data file.json delete arr[1:4]               # range (indices 1,2,3)
        data file.json delete arr[-3:]               # last 3 elements
        data file.json delete arr[::2]               # every other element
        data file.json delete arr[1:6:2]             # range with step
    \b
      Property subsets:
        data file.json delete "obj['a','b']"         # select specific keys
    \b
      Special characters in keys:
        data file.json delete '.["x-y"]'             # keys with hyphens, dots, etc.
    \b
      Scoped access with --at:
        data file.json delete name --at '$.user'     # equivalent to $.user.name
    """
    source = ctx.obj.get("source")
    if not source:
        click.echo("Error: SOURCE required", err=True)
        sys.exit(1)

    data_ctx = Context(at_prefix=at)

    if not paths:
        click.echo("Error: DELETE requires at least one path", err=True)
        sys.exit(1)

    try:
        execute_pipeline(
            ctx=data_ctx,
            source_spec=source,
            path_specs=list(paths),
            value_specs=[],
            command_fn=delete_command,
            command_name="delete",
            output_stdout=True,
            output_stderr=True,
            apply_at_prefix=True,  # DELETE applies --at prefix
            command_takes_value=False,
            output_file=output_file,
            backup=backup,
            force=force,
            quiet=quiet,
            shell_mode=shell,
        )
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.option("--array", "use_array", is_flag=True, help="Reset to empty array [] instead of empty object {}")
@click.option("--quiet", "-q", is_flag=True, help="Minimal output")
@click.pass_context
def reset(ctx: click.Context, use_array: bool, quiet: bool) -> None:
    """Reset a file to an empty object {} or empty array [].

    Replaces the shell anti-pattern: echo '{}' > file.json
    """
    source = ctx.obj.get("source") if ctx.obj else None
    if not source:
        click.echo("Error: SOURCE required", err=True)
        sys.exit(1)

    target = PathLib(source)
    target.parent.mkdir(parents=True, exist_ok=True)

    ext = target.suffix.lower()
    with target.open("w") as f:
        if ext in (".yaml", ".yml"):
            yaml.dump({} if not use_array else [], f, default_flow_style=False)
        elif ext == ".toml":
            f.write("")
        else:
            json.dump([] if use_array else {}, f)

    if not quiet:
        click.echo(json.dumps({"reset": "SUCCESS"}), err=True)


@main.command()
@click.argument("source1")
@click.argument("source2")
@click.option("--ignore", multiple=True, help="Paths to ignore in comparison")
@common_options
def diff(  # noqa: PLR0913
    source1: str,
    source2: str,
    ignore: tuple[str, ...],
    quiet: bool,
    shell: bool,
    output_file: str | None,
) -> None:
    """Compare two data sources.

    SOURCE1 is the first source to compare (file path or - for stdin).
    SOURCE2 is the second source to compare (file path, literal, or @file).
    """
    try:
        # Load first source
        ctx1 = Context()
        source1_obj = Source.parse(source1)
        source1_obj.load(ctx1)
        left_value = ctx1.data

        # Load second source - try as Source first, then as Value
        try:
            ctx2 = Context()
            source2_obj = Source.parse(source2)
            source2_obj.load(ctx2)
            right_value = ctx2.data
        except Exception:
            # If it's not a valid source, try as a Value
            value_obj = Value.parse(source2, ctx1)
            right_value = value_obj.prepared()

        # Run diff
        result = diff_command(
            query="$",
            path="$",
            left_value=left_value,
            right_value=right_value,
            ignore=list(ignore) if ignore else None,
        )

        # Output result
        output = {
            "status": "success",
            "identical": len(result) == 0,
            "results": result,
        }

        # Handle output routing
        if output_file:
            # Write to output file
            output_path = PathLib(output_file)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with output_path.open("w") as f:
                json.dump(output, f, indent=2)
            if not quiet:
                click.echo(json.dumps(output, indent=2))
        elif shell:
            # Shell mode: print differences
            if result:
                format_shell_output(result)
            else:
                format_shell_output([{"message": "No differences"}])
        else:
            # Normal JSON output
            click.echo(json.dumps(output, indent=2))

        # Envelope
        if not quiet:
            envelope = {"diff": "SUCCESS", "identical": len(result) == 0}
            click.echo(json.dumps(envelope), err=True)

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
