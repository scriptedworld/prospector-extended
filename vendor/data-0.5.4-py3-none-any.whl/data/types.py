"""Output data types for commands."""

from __future__ import annotations

import json
from dataclasses import dataclass
from enum import Enum
from typing import Any


class DataFormat(Enum):
    """Supported data formats for source files."""

    JSON = "json"
    YAML = "yaml"
    TOML = "toml"


@dataclass
class PathMatch:
    """Result of a GET query match.

    Attributes:
        query: The original query path
        path: The resolved JSONPath
        value: The matched value
    """

    query: str
    path: str
    value: Any

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary with query, path, and value keys
        """
        return {"query": self.query, "path": self.path, "value": self.value}


@dataclass
class DiffEntry:
    """A single difference between two values.

    Attributes:
        path: The JSONPath where the difference occurs
        left: The value from the left operand
        right: The value from the right operand
    """

    path: str
    left: Any
    right: Any

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary with path, left, and right keys
        """
        return {"path": self.path, "left": self.left, "right": self.right}


@dataclass
class Envelope:
    """Envelope message for command results (written to stderr).

    Attributes:
        command: The command name (get, set, append, delete, diff)
        status: Either "SUCCESS" or "FAIL"
        metadata: Additional command-specific metadata (for success)
        reason: Error description (for failure)
    """

    command: str
    status: str
    metadata: dict[str, Any] | None = None
    reason: str | None = None

    @classmethod
    def success(cls, command: str, metadata: dict[str, Any] | None = None) -> Envelope:
        """Create a success envelope.

        Args:
            command: The command name
            metadata: Additional command-specific data

        Returns:
            Success envelope instance
        """
        return cls(command=command, status="SUCCESS", metadata=metadata or {})

    @classmethod
    def failure(cls, command: str, reason: str) -> Envelope:
        """Create a failure envelope.

        Args:
            command: The command name
            reason: Error description

        Returns:
            Failure envelope instance
        """
        return cls(command=command, status="FAIL", reason=reason)

    def to_json(self) -> str:
        """Serialize envelope to JSON string.

        For success: {"<command>": "SUCCESS", ...metadata}
        For failure: {"<command>": "FAIL", "reason": "..."}

        Returns:
            JSON string representation
        """
        result: dict[str, Any] = {self.command: self.status}

        if self.status == "SUCCESS" and self.metadata:
            result.update(self.metadata)
        elif self.status == "FAIL" and self.reason:
            result["reason"] = self.reason

        return json.dumps(result)

    def to_quiet(self) -> str:
        """Serialize envelope to minimal quiet mode JSON.

        In quiet mode, only the status is included (no command name or metadata).

        Returns:
            Minimal JSON string with only status
        """
        return json.dumps({"status": self.status})
